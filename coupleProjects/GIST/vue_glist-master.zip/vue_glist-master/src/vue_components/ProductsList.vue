<template>
	<div class="products">
	</div>
</template>

<script>
    export default {
    }
</script>