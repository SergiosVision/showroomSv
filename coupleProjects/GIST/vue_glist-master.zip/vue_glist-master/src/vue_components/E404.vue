<template>
	<div>
		<h1>Page not found</h1>
		<hr>
		<router-link :to="'/'">Start from main page</router-link>
	</div>
</template>

<script>
	export default {
		
	}
</script>