import * as React from 'react'
import * as ReactDOM from 'react-dom'

import {Provider} from 'react-redux'
import {Route, Router, Switch} from 'react-router'

import {store, history} from 'store'

import Auth from 'modules/Auth/Auth'

const cx = require('classnames/bind').bind(require('./styles/styles.scss'))

import 'common/styles/base'
import SideBar from 'modules/SideBar/SideBar'
import ProfileContainer from 'modules/Profile/containers/ProfileContainer'

class Content extends React.Component {
    render() {
        return (
            <Provider store={store}>
                <Router history={history}>
                    <div className={cx('row', 'main')}>
                        <div className={cx('column md-1', 'sidebar-wrapper')}>
                            <SideBar/>
                        </div>
                        <div className={cx('column md-11', 'content-wrapper')}>
                            <Switch>
                                <Route path='/profile' component={ProfileContainer} />
                                <Route path='/auth' component={Auth} />
                            </Switch>
                        </div>
                    </div>
                </Router>
            </Provider>
        )
    }
}

ReactDOM.render(
    <Content />,
    document.getElementById('content')
)