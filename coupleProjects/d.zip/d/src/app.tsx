import * as React from 'react'
import * as ReactDOM from 'react-dom'

import {Provider} from 'react-redux'
import {Route, Router, Switch} from 'react-router-dom'

import {store, history} from 'store'

import Auth from 'modules/Auth/Auth'

const cookie = require('react-cookies')
const cx = require('classnames/bind').bind(require('./styles/styles.scss'))

import 'common/styles/base'
import SideBar from 'modules/SideBar/SideBar'
import Orders from 'modules/Orders/NewOrder/containers/NewOrderContainer'
import ProfileContainer from 'modules/Profile/containers/ProfileContainer'

class Content extends React.Component {
    state = {
        auth: false
    }

    componentWillMount() {
        const autheticated = !!cookie.load('accessToken')

        if (autheticated && location.pathname === '/auth') {
            return history.replace('/')
        } else if (!autheticated && location.pathname !== '/auth') {
            return history.replace('/auth')
        }
    }

    render() {
        const authenticated = !!cookie.load('accessToken')

        return (
            <Provider store={store}>
                <Router history={history}>
                    <div className={cx('row', 'main')}>
                        <div className={cx('column md-1', 'sidebar-wrapper')}>
                            {authenticated && <SideBar/>}
                        </div>
                        <div className={cx('column md-11', 'content-wrapper')}>
                            <Switch>
                                <Route path='/orders' component={Orders} />
                                <Route path='/profile' component={ProfileContainer} />
                                <Route path='/auth' component={Auth} />
                            </Switch>
                        </div>
                    </div>
                </Router>
            </Provider>
        )
    }
}

ReactDOM.render(
    <Content />,
    document.getElementById('content')
)