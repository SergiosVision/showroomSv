import {combineReducers} from 'redux'
import { reducer as formReducer } from 'redux-form'

import signInFormReducer, { SignInFormState } from './app/auth/SignIn/reducers/'
import signInUpMerchantFormReducer, { SignUpMerchantFormState } from './app/auth/SignUpMerchant/reducers/'
import signInUpEmployeeFormReducer, { SignUpEmployeeFormState } from './app/auth/SignUpEmployee/reducers/'
import forgotPasswordFormReducer, { ForgotPasswordFormState } from './app/auth/ForgotPassword/reducers/'
import newOrderFormReducer, { NewOrderFormState } from './app/fnb/orders/NewOrder/reducers'
import resetPasswordFormReducer, { ResetPasswordFormState } from './app/auth/ResetPassword/reducers/'
import profileReducer, { ProfileUpateState } from './app/profile/reducers/form'
import profilePageReducer, { ProfilePageState } from './app/profile/reducers/index'
import profileResetPasswordModalReducer, {ProfileChangePasswordModalState} from './app/common/modals/profileChangePassword/reducers'
import areasReducer, {AreasState} from './app/common/reducers/areas'
import languageReducer, {ChangeLanguageState} from './common/reducers/lang'
import authReducer, { AuthState } from './common/auth/reducers'
import OrdersListReducer, { RequestOrdersState } from './app/fnb/orders/Dashboard/reducers'

export interface State {
    areas: AreasState,
    profile: ProfileUpateState,
    profilePage: ProfilePageState,
    resetPasswordForm: ResetPasswordFormState,
    signInForm: SignInFormState,
    signUpMerchantForm: SignUpMerchantFormState,
    signUpEmployeeForm: SignUpEmployeeFormState,
    forgotPasswordForm: ForgotPasswordFormState,
    newOrderForm: NewOrderFormState,
    profileChangePasswordModal: ProfileChangePasswordModalState
    lang: ChangeLanguageState,
    auth: AuthState,
    ordersList: RequestOrdersState
}

const appReducer = combineReducers({
    areas: areasReducer,
    form: formReducer,
    profile: profileReducer,
    profilePage: profilePageReducer,
    resetPasswordForm: resetPasswordFormReducer,
    signInForm: signInFormReducer,
    signUpMerchantForm: signInUpMerchantFormReducer,
    signUpEmployeeForm: signInUpEmployeeFormReducer,
    forgotPasswordForm: forgotPasswordFormReducer,
    newOrderForm: newOrderFormReducer,
    profileChangePasswordModal: profileResetPasswordModalReducer,
    lang: languageReducer,
    auth: authReducer,
    ordersList: OrdersListReducer
})

export default appReducer
