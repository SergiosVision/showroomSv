import * as React from 'react'

import SideBarProfileContainer from './containers/SideBarProfileContainer'

class SideBarProfileMin extends React.Component {
    render() {
        return (
            <div>
                <SideBarProfileContainer/>
            </div>
        )
    }
}

export default SideBarProfileMin
