import * as React from 'react'
import {connect, DispatchProp} from 'react-redux'
import {State} from 'reducers'

import { ProfilePage } from 'common/types/profile'

import SideBarProfile from '../components/SideBarProfile'

import { setUser } from 'common/auth/actions'

interface Props {
    user: ProfilePage
}

interface DispatchProps {
    setUser: (payload: ProfilePage) => void
}

class Profile extends React.Component<Props & DispatchProps & DispatchProp<{}>> {
    render() {
        const { user } = this.props

        return (
            <div>
                <SideBarProfile
                    user={user}
                />
            </div>
        )
    }
}

const mapStateToProps = (state: State) => {
    return {
        user: state.auth.user
    }
}

export default connect(
    mapStateToProps,
    {
        setUser
    }
)(Profile as any)
