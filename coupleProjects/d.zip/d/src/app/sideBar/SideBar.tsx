import * as React from 'react'
import {Link} from 'react-router-dom'
import {ProfilePage} from 'common/types/profile'
import {InitialMenu} from 'common/types/initialMenu'
import UserReceiver from 'app/common/dataReceivers/ProfileReceiver'

import Navigation from 'app/sideBar/components/Navigation/Navigation'
import SideBarProfileMain from  'app/sideBar/components/Profile/SideBarProfileMain'

const Logo = require(`!svg-react-loader?name=Icon!common/img/logo-white.svg`)

const cx = require('classnames/bind').bind(require('./styles/styles.scss'))

class SideBar extends React.Component {
    state = {
        profile: undefined as ProfilePage
    }

    componentWillMount() {
        new UserReceiver()
            .receive((profile: ProfilePage) => this.setState({profile}))
    }

    render() {
        const { profile } = this.state
        let initialMenu: InitialMenu[] = []

        if (profile && profile.merchant_type === 1) { // F&B Merchant
            initialMenu = [
                {singlePath: 'orders'},
                {singlePath: 'customers'},
                {singlePath: 'drivers'}
            ]
        } else if (profile && profile.merchant_type === 2) { // Individual Merchant
            initialMenu = [
                {singlePath: 'orders'},
                {singlePath: 'reports'},
                {singlePath: 'customers'},
                {singlePath: 'history'},
                {singlePath: 'settings'}
            ]
        } else if (profile && profile.merchant_type === 3) { // Company
            initialMenu = [
                {singlePath: 'orders'},
                {singlePath: 'reports'},
                {singlePath: 'customers'},
                {singlePath: 'products'},
                {singlePath: 'history'},
                {singlePath: 'settings'}
            ]
        }

        return (
            <div className={cx('sidebar')}>
                <div className={cx('top-side')}>
                    <div className={cx('logo', 'mb-60')}>
                        <Link to='/orders'>
                            <Logo />
                        </Link>
                    </div>
                    <Navigation
                        initialMenu={initialMenu}
                    />
                </div>
                <div className={cx('bottom-side')}>
                    <SideBarProfileMain />
                    <div className={cx('copyright')}>
                            <span className={cx('copyright-text')}>
                                Copyright (c) {new Date().getFullYear()} Dizli.net.
                                <br/>
                                All rights reserved
                            </span>
                    </div>
                </div>
            </div>
        )
    }
}

export default SideBar
