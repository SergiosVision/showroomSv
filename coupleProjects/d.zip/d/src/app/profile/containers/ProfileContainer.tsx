import * as React from 'react'
import {connect, DispatchProp} from 'react-redux'
import {InjectedFormProps, reduxForm} from 'redux-form'
import axios, {AxiosError, AxiosResponse} from 'axios'
import {State} from 'reducers'

import {
    hideSubmitLoader,
    setProfileUpdateError,
    showSubmitLoader
} from '../actions/form'
import { setUser } from 'common/auth/actions'

import { changeLanguageId } from 'common/actions/lang'
import { checkExtension, checkFileSize } from 'common/utils/text'
import { openProfileChangePasswordModal } from 'app/common/modals/profileChangePassword/actions'
import { ProfilePage } from 'common/types/profile'
import { Select } from 'common/types/Select'
import TopSection from '../components/TopSection'
import Profile from '../components/Profile'

const cookie = require('react-cookies')

interface FormProps {
    first_name: string,
    last_name: string,
    phone: string,
    email: string,
    [key: string]: string
}

interface Props {
    errorMessage: string,
    isShowSubmitLoader: boolean,
    saveLoader: boolean,
    openProfileChangePasswordModal: () => void,
    isFetching: boolean,
    user: ProfilePage,
    errorUpdateProfile?: any,
    lang: Select
}

interface DispatchProps {
    setProfileUpdateError: (errorMessage: string) => void,
    showSubmitLoader: () => void,
    hideSubmitLoader: () => void,
    setUser: (payload: ProfilePage) => void,
    changeLanguageId: (lang: Select) => void
}

class ProfileContainer extends React.Component<Props & DispatchProps & DispatchProp<{}> & InjectedFormProps<FormProps>> {
    state = {
        editMode: false,
        imgUrl: undefined as string,
        fileExtensionError: false,
        fileSizeError: false,
        fileHolder: undefined as any
    }

    componentWillMount() {
        const { initialize, changeLanguageId, user } = this.props

        axios
            .get('/app/profile', {
                headers: { Authorization: cookie.load('accessToken')}
            })
            .then(
                (resposne: AxiosResponse) => {
                    const { user } = resposne.data

                    initialize({
                        first_name: user.first_name,
                        last_name:  user.last_name,
                        phone:      user.phone,
                        email:      user.email
                    })
                }
            )

        changeLanguageId({value: 'en', label: 'English'})
    }

    render() {
        const { editMode, imgUrl, fileExtensionError, fileSizeError } = this.state
        const {
            handleSubmit, saveLoader, openProfileChangePasswordModal,
            isFetching, user, errorUpdateProfile, lang
        } = this.props

        return (
           <div>
               <TopSection
                   editMode={editMode}
                   turnEditMode={this.turnEditMode}
                   offEditMode={this.offEditMode}
                   isShowSubmitLoader={saveLoader}
                   openModal={openProfileChangePasswordModal}
                   saveForm={handleSubmit(this.handleSaveProfile)}
                   user={user}
               />
               <Profile
                   editMode={editMode}
                   uploadImage={this.uploadImage}
                   removeImage={this.removeImage}
                   imgUrl={imgUrl}
                   user={user}
                   errorUpdateProfile={errorUpdateProfile}
                   isFetching={isFetching}
                   saveForm={handleSubmit(this.handleSaveProfile)}
                   fileExtensionError={fileExtensionError}
                   fileSizeError={fileSizeError}
                   lang={lang}
                   languageEvent={this.handleLanguageEvent}
               />
           </div>
        )
    }

    private turnEditMode = () => {
        this.setState({editMode: true})
    }

    private offEditMode = () => {
        const { setProfileUpdateError } = this.props

        this.setState({
            editMode: false,
            imgUrl: undefined as string,
            fileExtensionError: false,
            fileSizeError: false
        })

        setProfileUpdateError('')
    }

    private uploadImage = (e: any) => {
        this.setState({
            fileExtensionError: false,
            fileSizeError: false
        })

        let file = e.target.files[0]
        const reader = new FileReader()

        if (!checkExtension(file.type)) {
            this.setState({fileExtensionError: true})
        } else if (checkFileSize(file.size, 2)) {
            this.setState({fileSizeError: true})
        } else {
            reader.readAsDataURL(file)
            reader.onload = (res) => {
                this.setState({imgUrl: res.target.result})
            }
            this.setState({fileHolder: file})
        }
    }

    private removeImage = () => {
        this.setState({
            fileExtensionError: false,
            fileSizeError: false,
            imgUrl: undefined as string
        })
    }

    private handleLanguageEvent = (selectedOption: any) => {
        const { changeLanguageId } = this.props

        changeLanguageId(selectedOption)
    }

    private handleSaveProfile = (values: FormProps) => {
        const { showSubmitLoader, setProfileUpdateError, hideSubmitLoader, setUser } = this.props
        const { fileHolder } = this.state
        const formData = new FormData()

        for (let value of Object.keys(values)) {
            formData.append(value, values[value])
        }
        formData.append('avatar', fileHolder)

        showSubmitLoader()

        axios
            .post('/app/profile', formData)
            .then((response: AxiosResponse) => {
                const { user } = response.data

                setUser(user)
                setProfileUpdateError('')
                hideSubmitLoader()

                this.setState({
                    editMode: false
                })
            })
            .catch(
                (error: AxiosError) => {
                    hideSubmitLoader()
                    setProfileUpdateError(error.response.data.message)
                }
            )
    }
}

const ProfileReduxeForm = reduxForm({
    form: 'profilePageForm'
})(ProfileContainer)

const mapStateToProps = (state: State) => {
    return {
        errorMessage: state.resetPasswordForm.errorMessage,
        isShowSubmitLoader: state.resetPasswordForm.isShowSubmitLoader,
        saveLoader: state.profile.isShowSubmitLoader,
        user: state.auth.user,
        lang: state.lang.lang
    }
}

export default connect(
    mapStateToProps,
    {
        setProfileUpdateError, showSubmitLoader, hideSubmitLoader,
        openProfileChangePasswordModal, changeLanguageId, setUser
    }
)(ProfileReduxeForm as any)