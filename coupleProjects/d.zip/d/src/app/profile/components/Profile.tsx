import * as React from 'react'
import {Field} from 'redux-form'
import { ProfilePage } from 'common/types/profile'

import LabeledItem from 'common/components/formItems/LabeledItem'
import LabeledItemNoForm from 'common/components/formItems/LabeledItemNoForm'
import ProfileChangePasswordModalContainer from 'app/common/modals/profileChangePassword/containers/ProfileChangePasswordModalContainer'

import Photo from 'common/components/photo/Photo'
import SelectField from 'common/components/select/Select'

const cx = require('classnames/bind').bind(require('../styles/styles.scss'))

interface Props {
    editMode: boolean,
    uploadImage: (value: any) => void,
    removeImage: () => void,
    imgUrl: string,
    user: ProfilePage,
    errorUpdateProfile: any,
    isFetching: boolean
    saveForm: (e: React.FormEvent<HTMLFormElement>) => void,
    fileExtensionError: boolean,
    fileSizeError: boolean,
    lang: object,
    languageEvent: (selectOption: any) => void,
}

export default class Profile extends React.Component<Props> {
    render() {
        const {
            editMode, uploadImage, removeImage, imgUrl,
            errorUpdateProfile, user, saveForm, fileExtensionError,
            fileSizeError, languageEvent, lang
        } = this.props
        let content

        if (user) {
            content = (
                <div className='row bg-white'>
                    <div className={cx('column md-3', 'left-side', 'pl-40 pr-40')}>
                        <Photo
                            editMode={editMode}
                            removeImage={removeImage}
                            uploadImage={uploadImage}
                            fileExtensionError={fileExtensionError}
                            fileSizeError={fileSizeError}
                            imgUrl={imgUrl}
                            data={user.avatar}
                        />
                        <div className={cx('bottom-info', 'flex align-items-center justify-content-between')}>
                            <LabeledItemNoForm label='Account Type'
                                         text={
                                             user.type === 0 && 'Merchant'
                                             ||
                                             user.type === 1 && 'Freelance Driver'
                                             ||
                                             user.type === 2 && 'Company Driver'
                                             ||
                                             user.type === 3 && 'Dispatcher'
                                             ||
                                             user.type === 4 && 'Manager'
                                             ||
                                             user.type === 4 && 'Admin'
                                         }
                                         className={'mb-0'}
                            />
                            <LabeledItemNoForm label='Team' text='Team Alpha'/>
                        </div>
                    </div>
                    <div className={cx('column md-9', 'r-side')}>
                        <div className='pl-15 pt-30'>
                            <div className={cx('form-holder')}>
                                {errorUpdateProfile && <span className='error-message mt-10 mb-10'>{errorUpdateProfile}</span>}
                                <form onSubmit={saveForm}>
                                    <Field
                                        name='first_name'
                                        type='text'
                                        component={LabeledItem}
                                        label='First Name'
                                        text={user.first_name}
                                        editable={true}
                                        editMode={editMode}
                                    />
                                    <Field
                                        name='last_name'
                                        type='text'
                                        component={LabeledItem}
                                        label='Last Name'
                                        text={user.last_name}
                                        editable={true}
                                        editMode={editMode}
                                    />
                                    <Field
                                        name='phone'
                                        type='tel'
                                        component={LabeledItem}
                                        label='Phone Number'
                                        text={user.phone}
                                        editable={true}
                                        editMode={editMode}
                                    />
                                    <Field
                                        name='email'
                                        type='email'
                                        component={LabeledItem}
                                        label='E-mail'
                                        text={user.email}
                                        editable={true}
                                        editMode={editMode}
                                    />
                                </form>
                            </div>
                            <div className={cx('language-holder', 'mt-20')}>
                                <span className={cx('small-title')}>Language</span>
                                <SelectField
                                    multi={false}
                                    clear={false}
                                    search={false}
                                    selectClose={true}
                                    hideOptions={false}
                                    changeEvent={languageEvent}
                                    selected={lang}
                                    small
                                    options={[
                                        { value: 'en', label: 'English' },
                                        { value: 'ar', label: 'Arabic' }
                                    ]}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            )
        } else {
            content = <span>Loading...</span>
        }

        return (
            <div>
                {content}
                <ProfileChangePasswordModalContainer />
            </div>
        )
    }
}