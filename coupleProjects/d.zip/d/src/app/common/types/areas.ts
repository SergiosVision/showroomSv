export interface Areas {
    area: string
}