import { CustomerAddress } from 'common/types/customerData/CustomerAddress'

export interface Orders {
    id: number
    order_id: string
    assigned_to: {
        id: number
        type: number
        name: string
    },
    importance: number
    status: number
    delivery_date: string
    arrival_time: {
        from: string
        to: string
    },
    estimated_arrival_at: string
    customer: {
        id: number
        name: string
    },
    destination: CustomerAddress
}