import { Areas } from 'app/common/types/areas'

export const AREAS_REQUEST = 'areas/REQUEST'

export const requestAreas = () => {
    return {
        type: AREAS_REQUEST
    }
}

export const AREAS_ERROR = 'areas/ERROR'

export const errorAreas = (error: any) => {
    return {
        type: AREAS_ERROR,
        payload: {error}
    }
}

export const AREAS_SUCCESS = 'areas/SUCCESS'

export interface AreasPayload {
    areas: Areas[]
}

export const receiveAreas = (areas: AreasPayload) => {
    return {
        type: AREAS_SUCCESS,
        payload: areas
    }
}