import {Action, handleActions} from 'redux-actions'

import { ErrorPayload } from 'common/payloads/ErrorActionPayload'
import { Areas } from 'app/common/types/areas'
import {
    AREAS_REQUEST,
    AREAS_ERROR,
    AREAS_SUCCESS,
    AreasPayload
} from 'app/common/actions/areas'

export interface AreasState {
    isFetching: false,
    areas: Areas[],
    error?: any,
}

const initialState = {
    isFetching: false,
    areas: undefined,
    error: undefined
} as AreasState

const handleRequest = (state: AreasState) => {
    return {
        ...state,
        isFetching: true,
        areas: initialState.areas,
        error: undefined as any
    }
}

const handleError = (state: AreasState, action: Action<ErrorPayload>) => {
    return {
        ...state,
        isFetching: false,
        error: action.payload.error
    }
}

const handleSuccess = (state: AreasState, action: Action<AreasPayload>) => {
    return {
        ...state,
        isFetching: false,
        areas: action.payload,
        error: undefined as any
    }
}

export default handleActions<AreasState>(
    {
        [AREAS_REQUEST]: handleRequest,
        [AREAS_ERROR]: handleError,
        [AREAS_SUCCESS]: handleSuccess
    } as any,
    initialState
)