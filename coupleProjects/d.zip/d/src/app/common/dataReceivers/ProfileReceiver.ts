import axios, {AxiosResponse} from 'axios'
import {store} from 'store'

import {State} from 'reducers'
import { setUser } from 'common/auth/actions'
import { ProfilePage } from 'common/types/profile'

const cookie = require('react-cookies')

    export default class UserReceiver {
    public receive(handleSuccess: (user: ProfilePage) => void) {
        const dispatch = store.dispatch
        const state = store.getState() as State
        if (!state.auth.user) {
            axios
                .get('/app/profile')
                .then(
                    (json: AxiosResponse) => {
                        dispatch(setUser(json.data.user))
                        handleSuccess(json.data.user)
                    }
                )
        }
    }
}
