import axios, {AxiosRequestConfig, AxiosResponse} from 'axios'

const cookie = require('react-cookies')

export default (function () {
    axios.defaults.baseURL = process.env.SERVICE_URL

    axios.interceptors.request.use((config: AxiosRequestConfig) => {
        config.headers = {
            'Authorization': cookie.load('accessToken') || ''
        }

        const regExp = new RegExp('auth')
        let url = config.url.split('/')

        if (regExp.test(config.url)) {
            url.splice(1, 0, 'v1')
        } else {
            url.splice(2, 0, 'v1')
        }

        config.url = url.join('/')

        return config
    })

    axios.interceptors.response.use((response: AxiosResponse): any => response)
}())