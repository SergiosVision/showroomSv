import { Customer } from 'common/types/customerData/Customer'
import { CustomerAddress } from 'common/types/customerData/CustomerAddress'

export interface NewOrder {
    customer: Customer,
    customer_notification_type: Notification,
    destination: CustomerAddress,
    payment_type: number,
    proof_of_delivery: number,
    tasks: [number],
    amount: number,
    notes: string
    vehicle_type: number
}