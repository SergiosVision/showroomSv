import * as React from 'react'
import { Link } from 'react-router-dom'

import Button from 'common/components/buttons/Button'

const cx = require('classnames/bind').bind(require('../styles/styles.scss'))

interface Props {
    saveAndAssign: () => void,
    isShowSubmitLoader: boolean
}

export default class TopSection extends React.Component<Props> {
    render() {
        const { saveAndAssign, isShowSubmitLoader } = this.props

        return (
            <div>
                <div className={cx('top-section', 'flex align-items-center justify-content-between pl-15 pr-40 pt-30 pb-65')}>
                    <h3 className={cx('container-title')}>New Order</h3>
                    <div className={cx('buttons-holder', 'flex align-items-center')}>
                        <Button className={cx('save-order')} disabled={isShowSubmitLoader}>Save</Button>
                        <Button className={cx('save-and-assign-order')} disabled={isShowSubmitLoader} type='submit' onClick={saveAndAssign}>
                            {
                                isShowSubmitLoader ? 'Loading' : 'Save & Assign to Driver'
                            }
                        </Button>
                        <Link to='/orders'>
                            <Button red className={cx('cancel-order')} disabled={isShowSubmitLoader}>Cancel</Button>
                        </Link>
                    </div>
                </div>
                <div/>
            </div>
        )
    }
}