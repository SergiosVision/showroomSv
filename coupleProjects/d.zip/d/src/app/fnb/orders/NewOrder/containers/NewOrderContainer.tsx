import * as React from 'react'
import {connect, DispatchProp} from 'react-redux'
import {InjectedFormProps, reduxForm} from 'redux-form'
import axios, {AxiosError, AxiosResponse} from 'axios'

import {history} from 'store'
import {State} from 'reducers'
import {
    hideSubmitLoader,
    setFormError,
    showSubmitLoader,
    requestAddress,
    successAddressRequest,
    newAddressRequest
} from '../actions/index'
import {
    requestAreas,
    errorAreas,
    receiveAreas
} from 'app/common/actions/areas'
import { changeAddress } from '../actions/fnbAddress'
import { CustomerAddress } from 'common/types/customerData/CustomerAddress'
import { Select } from 'common/types/Select'
import { Areas } from 'app/common/types/areas'

import TopSection from '../components/TopSection'
import NewOrder from '../components/NewOrder'

const cookie = require('react-cookies')

interface FormProps {
    order_id: string,
    phone: string,
    first_name: string,
    last_name: string,
    email: string,
    destination: any,
    customer_notification_type: number,
    proof_of_delivery: number,
    payment_type: string,
    vehicle_type: string,
    amount: string,
    notes: string,
    area: string,
    block: string,
    street: string,
    jadda: string,
    building: string,
    floor: string,
    apartment: string
}

interface Props {
    errorMessage: string,
    isShowSubmitLoader: boolean,
    destination: any
    addressId: number,
    addresses: CustomerAddress[],
    areas: Areas[]
}

interface DispatchProps {
    showSubmitLoader: () => void,
    hideSubmitLoader: () => void,
    setFormError: (error: any) => void
    changeAddress: (id: number) => void,
    requestAddress: () => void,
    successAddressRequest: (address: CustomerAddress[]) => void,
    newAddressRequest: (newAddress: CustomerAddress) => void,
    requestAreas: () => void
    errorAreas: (error: any) => void
    receiveAreas: (areas: Areas[]) => void
}

class NewOrderContainer extends React.Component<Props & DispatchProps & DispatchProp<{}> & InjectedFormProps<FormProps>> {
    state = {
        newAddressShow: false,
        notificationValue: [{ value: '1', label: 'SMS' }],
        proofValue: [{ value: '1', label: 'Signature' }],
        tasksValue: [{ value: '1', label: 'Tell about discounts' }],
        area: { value: '0', label: `Hawalli` }
    }

    componentWillMount() {
        const { initialize, requestAddress, successAddressRequest, requestAreas, receiveAreas } = this.props

        const placeHolderData = [
            {
                area: 'Hawalli',
                block: 1,
                street: 'Abu Dhabi St',
                jadda: 1,
                building: '1a',
                floor: 1,
                apartment: 1,
                latitude: 90,
                longitude: 90
            },
            {
                area: 'Ahmadi',
                block: 4,
                street: 'Abu Dabhi St',
                jadda: 0,
                building: '28',
                floor: 7,
                apartment: 108,
                latitude: 90,
                longitude: 90
            },
            {
                area: 'Jahra',
                block: 1,
                street: 'Airport Rd',
                jadda: 0,
                building: '888',
                floor: 250,
                apartment: 55,
                latitude: 90,
                longitude: 90
            },
            {
                area: 'Jahra2',
                block: 1,
                street: 'Airport Rd',
                jadda: 0,
                building: '999',
                floor: 255,
                apartment: 74,
                latitude: 90,
                longitude: 90
            },
            {
                area: 'Test 1',
                block: 1,
                street: 'Airport Test 1',
                jadda: 1,
                building: '111',
                floor: 100,
                apartment: 666,
                latitude: 90,
                longitude: 90
            }
        ]

        const placeHolderAreas = [
            {area: 'Hawalli'},
            {area: 'Ahmadi'},
            {area: 'Jahra'}
        ]

        requestAddress()

        successAddressRequest(placeHolderData)

        requestAreas()

        receiveAreas(placeHolderAreas)

        initialize({
            payment_type: '1',
            vehicle_type: '1'
        })
    }

    render() {
        const { handleSubmit, isShowSubmitLoader, addresses, areas } = this.props
        const { notificationValue, proofValue, tasksValue, area, newAddressShow } = this.state

        return (
           <div>
               <TopSection
                    saveAndAssign={handleSubmit(this.saveAndAssign)}
                    isShowSubmitLoader={isShowSubmitLoader}
               />
               <NewOrder
                    handleNotificationEvent={this.handleChangeNotification}
                    notificationValue={notificationValue}
                    handleProofEvent={this.handleChangeProof}
                    proofValue={proofValue}
                    handleTasksEvent={this.handleChangeTasks}
                    tasksValue={tasksValue}
                    handleAreaValueChange={this.handleChangeArea}
                    areaValue={area}
                    saveAndAssign={handleSubmit(this.saveAndAssign)}
                    handlePhoneChange={this.handleSearch}
                    addresses={addresses}
                    areas={areas}
                    newAddressShow={newAddressShow}
                    newAddressEvent={this.callNewAddress}
               />
           </div>
        )
    }

    private handleChangeNotification = (selectedOption: any) => {
        this.setState({ notificationValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({notificationValue: [{ value: '1', label: 'SMS' }]})
        }
    }

    private handleChangeProof = (selectedOption: any) => {
        this.setState({ proofValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({proofValue: [{ value: '1', label: 'Signature' }]})
        }
    }

    private handleChangeArea = (selectOption: any) => {
        this.setState({area: selectOption})
    }

    private handleChangeTasks = (selectedOption: any) => {
        this.setState({ tasksValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({tasksValue: [{ value: '1', label: 'Tell about discounts' }]})
        }
    }

    private handleSearch = (e: any) => {
        const { setFormError } = this.props

        if (e.target.value.length >= 5) {
            axios
                .get(`/app/customers/search?phone=${e.target.value}`)
                .then((response: AxiosResponse) => {
                    setFormError('')
                    console.log(response.data)
                })
                .catch(
                    (error: AxiosError) => {
                        setFormError(error.response.data.message)
                    }
                )
        }
    }

    private callNewAddress = () => {
        this.setState({newAddressShow: true})
    }

    private newAddress = (values: FormProps) => {
        const { area } = this.state

        return {
            area: area.label,
            block: parseInt(values.block),
            street: values.street,
            jadda: values.jadda !== '-' ? parseInt(values.jadda) : 1,
            building: values.building,
            floor: parseInt(values.floor),
            apartment: parseInt(values.apartment),
            latitude: 90,
            longitude: 90
        }
    }

    private convertToBitMask = (value: Select[]) => {
        let arr: Array<number> = []

        value.map(item => {
            arr.push(parseInt(item.value))
        })

        return arr.reduce((accumulator, curVal) => accumulator | (curVal))
    }

    private getValuesFromTasks = (value: Select[]) => {
        let arr: Array<number> = []

        value.map(item => {
            arr.push(parseInt(item.value))
        })

        return arr
    }

    private saveAndAssign = (values: FormProps) => {
        const { setFormError, showSubmitLoader, hideSubmitLoader, addresses  } = this.props
        const { notificationValue, proofValue, tasksValue } = this.state

        const data = {
            order_id: values.order_id,
            customer: {
                id: addresses.length + 1,
                first_name: values.first_name,
                last_name: 'Test',
                email: values.email,
                phone: values.phone
            },
            customer_notification_type: this.convertToBitMask(notificationValue),
            destination: addresses.length < parseInt(values.destination ) ? this.newAddress(values) : addresses[values.destination],
            proof_of_delivery: this.convertToBitMask(proofValue),
            tasks: this.getValuesFromTasks(tasksValue),
            amount: parseFloat(values.amount),
            notes: values.notes,
            payment_type: parseInt(values.payment_type),
            vehicle_type: parseInt(values.vehicle_type)
        }

        showSubmitLoader()

        axios
            .post('/fnb/orders', data)
            .then((response: AxiosResponse) => {
                setFormError('')
                hideSubmitLoader()
                console.log(response.data)
                history.push('/')
            })
            .catch(
                (error: AxiosError) => {
                    hideSubmitLoader()
                    setFormError(error.response.data.message)
                }
            )
    }
}

const validate = (values: FormProps) => {
    const errors = {} as any
    const requiredMessage = 'This field is required.'

    if (!values.order_id) {
        errors.order_id = requiredMessage
    }

    if (!values.phone) {
        errors.phone = requiredMessage
    }

    if (!values.first_name) {
        errors.first_name = requiredMessage
    }

    if (!values.amount) {
        errors.amount = requiredMessage
    }

    if (!values.destination) {
        errors.destination = requiredMessage
    }

    return errors
}

const NewOrderReduxeForm = reduxForm({
    form: 'newOrderForm',
    validate
})(NewOrderContainer)

const mapStateToProps = (state: State) => {
    return {
        isShowSubmitLoader: state.newOrderForm.isShowSubmitLoader,
        errorMessage: state.newOrderForm.errorMessage,
        addressId: state.newOrderForm.addressId,
        addresses: state.newOrderForm.addresses,
        areas: state.areas.areas
    }
}

export default connect(
    mapStateToProps,
    {
        setFormError,
        showSubmitLoader,
        hideSubmitLoader,
        changeAddress,
        requestAddress,
        successAddressRequest,
        newAddressRequest,
        requestAreas,
        errorAreas,
        receiveAreas
    }
)(NewOrderReduxeForm as any)