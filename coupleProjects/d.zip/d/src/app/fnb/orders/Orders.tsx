import * as React from 'react'
import {Route, Switch, RouteComponentProps} from 'react-router-dom'

import Dashboard from './Dashboard/containers/DashboardContainer'
import NewOrderContainer from './NewOrder/containers/NewOrderContainer'

class Orders extends React.Component<RouteComponentProps<{}>> {
    render() {
        return (
            <div>
                <Switch>
                    <Route exact path={`${this.props.match.path}/`} component={Dashboard} />
                    <Route exact path={`${this.props.match.path}/new-order`} component={NewOrderContainer} />
                </Switch>
            </div>
        )
    }
}

export default Orders