import * as React from 'react'
import { Orders } from 'app/common/types/orders'
import { SortingPayload } from 'common/payloads/SortingPayload'
import SelectField from 'common/components/select/Select'
import {Select} from 'common/types/Select'
import { Field } from 'redux-form'
import Checkbox from 'common/components/formItems/Checkbox'

import Accordion from 'common/components/accordion/Accordion'

const moment = require('moment-timezone')
const cx = require('classnames/bind').bind(require('../styles/styles.scss'))

interface Props {
    ordersList: Orders[],
    sorting: SortingPayload,
    changeSorting: (sorting: SortingPayload) => void,
    tabsValue: Select,
    handleTabsEvent: (selectedOption: Select) => void
}

export default class Dashboard extends React.Component<Props> {
    render() {
        const { ordersList, sorting, changeSorting, tabsValue, handleTabsEvent } = this.props

        const checkBoxes = [
            {
                name: 'all',
                label: 'All Statuses',
                count: 0
            },
            {
                name: 'created',
                label: 'Created',
                count: 0
            },
            {
                name: 'ready_for_delivery',
                label: 'Ready for Delivery',
                count: 0
            },
            {
                name: 'out_of_delivery',
                label: 'Out for Delivery',
                count: 0
            },
            {
                name: 'late',
                label: 'Late',
                count: 0
            },
            {
                name: 'completed',
                label: 'Completed',
                count: 0
            },
            {
                name: 'canceled',
                label: 'Canceled',
                count: 0
            }
        ]

        const content = (
            ordersList && ordersList.map((item, index, array) => {
                return (
                    <tr key={item.id}>
                        <td>
                            <span>
                                {item.order_id}
                            </span>
                        </td>
                        <td>
                            <span className={
                                item.status === 1 ? 'text-aqa-blue' : undefined
                                ||
                                item.status === 2 ? 'text-title-gray' : undefined
                                ||
                                item.status === 3 ? 'text-orange-danger' : undefined
                                ||
                                item.status === 4 ? ' text-danger' : undefined
                                ||
                                item.status === 5 ? 'text-success-green' : undefined
                            }
                            >
                                {
                                    item.status === 1 && 'Waiting for Payment'
                                    ||
                                    item.status === 2 && 'Created'
                                    ||
                                    item.status === 3 && 'Out for Delivery'
                                    ||
                                    item.status === 4 && 'Cancelled'
                                    ||
                                    item.status === 5 && 'Completed'
                                }
                            </span>
                        </td>
                        <td className={cx('driver')}>
                            <div className={cx('driver-holder')}>
                                <span>
                                {item.assigned_to.name}
                            </span>
                                {
                                    item.assigned_to.type === 1 &&
                                    <span className={cx('badge')}>
                                    FD
                                </span>
                                }
                                {
                                    item.assigned_to.type === 2 &&
                                    <div className={cx('badge')}>
                                        CD
                                    </div>
                                }
                            </div>
                        </td>
                        <td>
                            <span>
                                {moment.tz(item.estimated_arrival_at, 'Asia/Kuwait').format('h:mm A')}
                            </span>
                        </td>
                        <td>
                            <span>
                                {item.customer.name}
                            </span>
                        </td>
                        <td className={cx('address')}>
                            <div className={cx('address-holder')}>
                                <span className={cx('area', 'address-item')}>
                                {item.destination.area}
                            </span>,{' '}
                                <span className={cx('block', 'address-item')}>
                                Block{' '}{item.destination.block}
                            </span>,{' '}
                                <span className={cx('street', 'address-item')}>
                                Street{' '}{item.destination.street}
                            </span>,{' '}
                                <span className={cx('jadda', 'address-item')}>
                                Jadda{' '}{item.destination.jadda}
                            </span>,{' '}
                                <span className={cx('apt', 'address-item')}>
                                apt.{' '}{item.destination.apartment}
                            </span>
                            </div>
                        </td>
                    </tr>
                )
            })
        )

        const headers = [
            {
                field: 'orderID',
                label: 'Order ID'
            },
            {
                field: 'status',
                label: 'Status'
            },
            {
                field: 'assigned_to_name',
                label: 'Driver'
            },
            {
                field: 'estimated_arrival_at',
                label: 'ETA'
            },
            {
                field: 'customer',
                label: 'Customer'
            },
            {
                field: 'address',
                label: 'Address'
            }
        ].map((item, index) => {
            return (
                <th
                    data-field={item.field}
                    data-sort-direction={sorting.field === item.field ? sorting.direction : 'asc'}
                    key={index}
                    className={cx('table-item', {
                        asc: sorting.field === item.field && sorting.direction === 'asc',
                        desc: sorting.field === item.field && sorting.direction === 'desc'
                    })}
                    onClick={(e) => {
                        changeSorting({
                            field: e.currentTarget.dataset.field,
                            direction: e.currentTarget.dataset.sortDirection === 'asc' ? 'desc' : 'asc'
                        })
                    }}
                >
                    <span>
                        {item.label}
                    </span>
                </th>
            )
        })

        return (
            <div>
                <div className='row bg-white'>
                    <div className={cx('left-side')}>
                        <div className={cx('left-top-side')}>
                            <div className={cx('tab-control')}>
                                <SelectField
                                    multi={false}
                                    clear={false}
                                    search={false}
                                    selectClose={true}
                                    full_width
                                    bold_title
                                    hideOptions={false}
                                    changeEvent={handleTabsEvent}
                                    selected={tabsValue}
                                    options={[
                                        { value: '1', label: 'Restaurant 1' },
                                        { value: '2', label: 'Restaurant 2' }
                                    ]}
                                />
                            </div>
                            <div className={cx('tabs-holder', 'pl-20 pr-10')}>
                                <div className={cx('restaurant-address', 'mt-10')}>862 Jacobs Trace Suite 221</div>
                                <div className={cx('agents-holder')}>
                                    <ul>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                        <li className={cx('list-items')}>Benjamin Jenkins (0)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className={cx('left-bottom-side', 'pl-20 pr-20 mt-20')}>
                            <div className='flex justify-content-between align-content-center'>
                                <div className={cx('font-lato-bold text-title-black', 'status-title')}>Status</div>
                                <div className={cx('clear-button', 'text-company-green')}>Clear</div>
                            </div>
                            <form className={cx('checkboxes-holder', 'mt-20')}>
                                <ul className={cx('checkbox-list')}>
                                    {
                                        checkBoxes.map((item, index) => {
                                            return (
                                                <li key={index}>
                                                    <Field
                                                        name={item.name}
                                                        label={item.label}
                                                        count={item.count}
                                                        component={Checkbox}
                                                    />
                                                </li>
                                            )
                                        })
                                    }
                                </ul>
                            </form>
                        </div>
                    </div>
                    <div className={cx('right-side')}>
                        <div className={cx('table-holder')}>
                            <table className={cx('table')}>
                                <thead>
                                    <tr>
                                        {headers}
                                    </tr>
                                </thead>
                                <tbody>
                                    {content}
                                </tbody>
                            </table>
                            <Accordion
                                label='Test 1'
                                index={0}
                                classN='mt-40'
                            >
                                content
                            </Accordion>
                            <Accordion
                                label='Test 2'
                                index={1}
                                classN='mt-40'
                            >
                                content
                            </Accordion>
                            <Accordion
                                label='Test 3'
                                index={2}
                                classN='mt-40'
                            >
                                content
                            </Accordion>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}