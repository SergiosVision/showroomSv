import * as React from 'react'
import {Link} from 'react-router-dom'

import Searchbar from 'common/components/Searchbar/Searchbar'
import Button from 'common/components/buttons/Button'

const cx = require('classnames/bind').bind(require('../styles/styles.scss'))

interface Props {
    searchBarEvent: (e: any) => void,
    searchSubmitEvent: () => void,
    keyDownEvent: (e: any) => void
}

export default class TopSection extends React.Component<Props> {
    render() {
        const { searchBarEvent, searchSubmitEvent, keyDownEvent } = this.props

        return (
            <div>
                <div className={cx('top-section', 'flex align-items-center justify-content-between')}>
                    <div className={cx('left-side-top')}>
                        <h3 className={cx('container-title')}>Dashboard</h3>
                        <span className={cx('date-top', 'mt-10')}>April 21</span>
                    </div>
                    <div className={cx('right-side-top')}>
                        <div className={cx('controls')}>
                            <Searchbar
                                changeEvent={searchBarEvent}
                                submitEvent={searchSubmitEvent}
                                onKeyDownEvent={keyDownEvent}
                                icon='search'
                                placeholder='Search'
                            />
                            <div className={cx('buttons-holder', 'ml-20')}>
                                <Link to='/orders/new-order'>
                                    <Button fill_red className={cx('new-order')}>New Order</Button>
                                </Link>
                            </div>
                        </div>
                        <div className={cx('progress-info', 'mt-30')}>
                            <div className={cx('progress-info-in', 'progress-info-item')}>
                                In Progress:{' '}<span className={cx('text-success-green')}>2</span>
                            </div>
                            <div className={cx('progress-info-late', 'progress-info-item')}>
                                Late:{' '} <span className={cx('text-danger')}>0</span>
                            </div>
                            <div className={cx('progress-info-completed', 'progress-info-item')}>
                                Completed:{' '} <span className={cx('text-aqa-blue')}>5</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div/>
            </div>
        )
    }
}