import * as React from 'react'
import {connect, DispatchProp} from 'react-redux'
import {State} from 'reducers'
import {InjectedFormProps, reduxForm} from 'redux-form'
import axios, {AxiosError, AxiosResponse} from 'axios'
import * as queryString from 'query-string'

import { Orders } from 'app/common/types/orders'
import {SortingPayload} from 'common/payloads/SortingPayload'
import {Select} from 'common/types/Select'

import {
    requestOrdersError,
    requestOrdersSuccess,
    setOrdersSorting
} from '../actions'

import TopSection from '../components/TopSection'
import Dashboard from '../components/Dashboard'

const cookie = require('react-cookies')

interface FormProps {
    all: boolean,
    created: boolean,
    ready_for_delivery: boolean,
    out_of_delivery: boolean,
    late: boolean,
    completed: boolean,
    canceled: boolean
}

interface Props extends InjectedFormProps<FormProps> {
    sorting: SortingPayload,
    forceLoad: boolean,
    ordersList: Orders[]
}

interface DispatchProps {
    requestOrdersError: (error: any) => void,
    requestOrdersSuccess: (orders: Orders[]) => void,
    setOrdersSorting: (sorting: SortingPayload) => void
}

class DashboardContainer extends React.Component<Props & DispatchProps & DispatchProp<{}>> {
    state = {
        tabsValue: {value: '1', label: 'Restaurant 1'}
    }

    componentWillMount() {
        const { requestOrdersSuccess, forceLoad, ordersList, initialize } = this.props

        initialize({
            all: true
        })

        const dataPlaceHolder: Orders[] = [
            {
                id: 1,
                order_id: '987654321',
                assigned_to: {
                    id: 1,
                    type: 2,
                    name: 'Jon Snow'
                },
                importance: 2,
                status: 4,
                delivery_date: '2018-09-05',
                arrival_time: {
                    from: '18:00',
                    to: '19:45'
                },
                estimated_arrival_at: '2018-09-05T12:00:00+00:00',
                customer: {
                    id: 1,
                    name: 'Jon Dr. Zoidberg'
                },
                destination: {
                    area: 'Hawalli',
                    block: 1,
                    street: 'Abu Dhabi St',
                    jadda: 1,
                    building: '1a',
                    floor: 20,
                    apartment: 43,
                    latitude: 83.21832,
                    longitude: 172.18623
                }
            },
            {
                id: 2,
                order_id: '141623869',
                assigned_to: {
                    id: 1,
                    type: 1,
                    name: 'Jon Snow'
                },
                importance: 2,
                status: 3,
                delivery_date: '2018-09-05',
                arrival_time: {
                    from: '18:00',
                    to: '19:45'
                },
                estimated_arrival_at: '2018-09-05T12:00:00+00:00',
                customer: {
                    id: 1,
                    name: 'Abulaziz'
                },
                destination: {
                    area: 'Ahmadi',
                    block: 1,
                    street: 'Abu Dhabi St',
                    jadda: 1,
                    building: '4a',
                    floor: 25,
                    apartment: 43,
                    latitude: 83.21832,
                    longitude: 172.18623
                }
            },
            {
                id: 3,
                order_id: '569884138',
                assigned_to: {
                    id: 1,
                    type: 1,
                    name: 'Jon'
                },
                importance: 2,
                status: 1,
                delivery_date: '2018-09-05',
                arrival_time: {
                    from: '18:00',
                    to: '19:45'
                },
                estimated_arrival_at: '2018-09-05T12:00:00+00:00',
                customer: {
                    id: 1,
                    name: 'Abulaziz'
                },
                destination: {
                    area: 'Ahmadi',
                    block: 1,
                    street: 'Abu Dhabi St',
                    jadda: 1,
                    building: '4a',
                    floor: 25,
                    apartment: 43,
                    latitude: 83.21832,
                    longitude: 172.18623
                }
            }
        ]

        requestOrdersSuccess(dataPlaceHolder)

        this.handleInitOrders()
    }

    render() {
        const { tabsValue } = this.state
        const { ordersList, sorting } = this.props

        return (
            <div>
                <TopSection
                    searchBarEvent={this.searchBarEvent}
                    searchSubmitEvent={this.searchSubmitEvent}
                    keyDownEvent={this.keyDownEvent}
                />
                <Dashboard
                    ordersList={ordersList}
                    sorting={sorting}
                    changeSorting={this.handleChangeSorting}
                    handleTabsEvent={this.handleTabsEvent}
                    tabsValue={tabsValue}
                />
            </div>
        )
    }

    private searchBarEvent = (e: any) => {
        const { value } = e.target
        // console.log(value)
    }

    private keyDownEvent = (e: any) => {
        if (e.keyCode === 13) {
            this.searchSubmitEvent()
        }
    }

    private searchSubmitEvent = () => {
        console.log('Submit')
    }

    private handleInitOrders = (sorting?: SortingPayload) => {
        const { requestOrdersError } = this.props

        if (sorting) {
            this.props.setOrdersSorting(sorting)
        }

        // requestOrders()
        //
        // axios.get(`${process.env.SERVICE_URL}/orders/dashboard?${this.composeQueryString(sorting)}`, {
        //     headers: { Authorization: cookie.load('accessToken')}
        // })
        //     .then(
        //         (response: AxiosResponse) => {
        //             console.log(response.data)
        //         }
        //     )
        //     .catch(error => requestOrdersError(error.message))
    }

    private handleTabsEvent = (selectedOption: Select) => {
        this.setState({tabsValue: selectedOption})
    }

    private composeQueryString = (sorting?: SortingPayload): string => {
        let params = {
            sort_column: 'estimated_arrival_at',
            sort_direction: 'asc',
            page: '1',
            filters: undefined as string,
            teams: undefined as string
        }

        if (sorting && sorting.field && sorting.direction) {
            params.sort_column = sorting.field
            params.sort_direction = sorting.direction
        }

        return queryString.stringify(params)
    }

    private handleChangeSorting = (sorting: SortingPayload) => {
        this.handleInitOrders(sorting)
    }
}

const FilterForm = reduxForm({
    form: 'FilterForm'
})(DashboardContainer)

const mapStateToProps = (state: State) => {
    return {
        ordersList: state.ordersList.orders,
        sorting: state.ordersList.sorting,
        forceLoad: state.ordersList.forceLoad
    }
}

export default connect(
    mapStateToProps,
    {
        requestOrdersError,
        requestOrdersSuccess,
        setOrdersSorting
    }
)(FilterForm as any)