import { Orders } from 'app/common/types/orders'
import { SortingPayload } from 'common/payloads/SortingPayload'

export interface OrdersListPayload {
    orders: Orders[]
}

export const ORDERS_ERROR = 'orders_list/ERROR'

export const requestOrdersError = (error: any) => {
    return {
        type: ORDERS_ERROR,
        payload: { error }
    }
}

export const ORDERS_SUCCESS = 'orders_list/SUCCESS'

export const requestOrdersSuccess = (orders: Orders) => {
    return {
        type: ORDERS_SUCCESS,
        payload: orders
    }
}

export const SET_ORDERS_SORTING = 'orders_list/SET_SORTING'

export function setOrdersSorting(sorting: SortingPayload) {
    return {
        type: SET_ORDERS_SORTING,
        payload: sorting
    }
}

export const SET_FORCE_LOAD = 'orders_list/SET_FORCE_LOAD'

export function setOrdersForceLoad(value: boolean) {
    return {
        type: SET_FORCE_LOAD,
        payload: value
    }
}