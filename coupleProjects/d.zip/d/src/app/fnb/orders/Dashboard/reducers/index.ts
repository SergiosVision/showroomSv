import {Action, handleActions} from 'redux-actions'
import { ErrorPayload } from 'common/payloads/ErrorActionPayload'
import { Orders } from 'app/common/types/orders'
import {SortingPayload} from 'common/payloads/SortingPayload'

import {
    ORDERS_ERROR,
    ORDERS_SUCCESS,
    SET_ORDERS_SORTING,
    SET_FORCE_LOAD,
    OrdersListPayload
} from '../actions'

export interface RequestOrdersState {
    isFetching: boolean,
    orders: Orders[],
    sorting: SortingPayload
    error?: any,
    forceLoad: boolean
}

const initialState = {
    isFetching: false,
    orders: undefined as Orders[],
    sorting: {
        field: undefined as string,
        direction: undefined as string
    },
    error: undefined as any,
    forceLoad: false
}

const handleRequestError = (state: RequestOrdersState, action: Action<ErrorPayload>) => {
    return {
        ...state,
        isFetching: false,
        error: action.payload
    }
}

const handleRequestSuccess = (state: RequestOrdersState, action: Action<OrdersListPayload>) => {
    return {
        ...state,
        isFetching: initialState.isFetching,
        forceLoad: initialState.forceLoad,
        orders: action.payload,
        error: initialState.error
    }
}

const handleSetSorting = (state: RequestOrdersState, action: Action<SortingPayload>) => {
    return {
        ...state,
        sorting: {...action.payload}
    }
}

const handleSetForceLoad = (state: RequestOrdersState, action: Action<{}>) => {
    return {
        ...state,
        forceLoad: action.payload
    }
}

export default handleActions<RequestOrdersState>(
    {
        [ORDERS_ERROR]: handleRequestError,
        [ORDERS_SUCCESS]: handleRequestSuccess,
        [SET_ORDERS_SORTING]: handleSetSorting,
        [SET_FORCE_LOAD]: handleSetForceLoad
    } as any,
    initialState
)