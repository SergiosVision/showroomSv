export interface SelectData {
    value: string,
    label: string
}