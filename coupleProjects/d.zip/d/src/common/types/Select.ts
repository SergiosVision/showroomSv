export interface Select {
    value: string
    label: string
}