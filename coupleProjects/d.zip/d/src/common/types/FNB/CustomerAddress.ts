export interface CustomerAddress {
    area: string,
    block: number,
    street: string,
    jadda: number,
    building:  string,
    floor: number,
    apartment: number,
    latitude: number,
    longitude: number
}