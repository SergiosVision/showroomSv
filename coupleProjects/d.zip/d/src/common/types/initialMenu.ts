export interface InitialMenu {
    singlePath: string
}