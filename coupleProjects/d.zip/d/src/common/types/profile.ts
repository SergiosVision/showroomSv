export interface ProfilePage {
    avatar: string,
    id: number,
    merchant_id: number,
    merchant_type: number,
    type: number,
    first_name: string,
    last_name: string
    email: string,
    phone: string
}