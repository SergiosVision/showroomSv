import { Vehicle } from 'common/enums/vehicle'
import { Notification } from 'common/enums/notification'
import { Payment } from 'common/enums/payment'
import { Proof } from 'common/enums/proof'

export interface NewOrder {
    customer: {
        id: number,
        first_name: string,
        last_name: string,
        email: string,
        phone: string
    },
    customer_notification_type: Notification,
    destination: {
        area: string,
        block: number,
        street: string,
        jadda: number,
        building: string,
        floor: number,
        apartment: number,
        latitude: number,
        longitude: number
    },
    payment_type: Payment,
    proof_of_delivery: Proof,
    tasks: [number],
    amount: number,
    notes: string
    vehicle_type: Vehicle
}