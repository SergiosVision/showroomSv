import { Vehicle } from 'common/enums/vehicle'
import { Notification } from 'common/enums/notification'
import { Payment } from 'common/enums/payment'
import { Proof } from 'common/enums/proof'
import { Customer } from 'common/types/FNB/Customer'
import { CustomerAddress } from 'common/types/FNB/CustomerAddress'

export interface NewOrder {
    customer: Customer,
    customer_notification_type: Notification,
    destination: CustomerAddress,
    payment_type: Payment,
    proof_of_delivery: Proof,
    tasks: [number],
    amount: number,
    notes: string
    vehicle_type: Vehicle
}