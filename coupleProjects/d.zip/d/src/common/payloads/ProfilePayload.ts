import { ProfilePage } from 'common/types/profile'

export interface ProfilePayload {
    user: ProfilePage
}