export interface SortingPayload {
   field: string
   direction: string
}