export interface ErrorPayload {
    error: {}
}