export const checkExtension = (value: string) => {
    let regExp = new RegExp('((?:image\\/jpeg|image\\/png)$)')
    return regExp.test(value)
}

export const checkFileSize = (value: number, limit: number) => {
    let size = value / 1024 / 1024
    return size > limit
}