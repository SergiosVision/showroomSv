import {Action, handleActions} from 'redux-actions'

import {ErrorPayload} from 'common/payloads/ErrorActionPayload'
import {ProfilePage} from 'common/types/profile'
import {PROFILE_ERROR, PROFILE_REQUEST, PROFILE_SUCCESS, SET_PROFILE, RESET_PROFILE, ProfilePayload} from '../actions/setProfile'

export interface SetProfileState {
    isFetching: boolean,
    profile: ProfilePage,
    error?: any,
}

const initialState = {
    isFetching: false,
    profile: undefined,
    error: undefined
} as SetProfileState

function handleRequest(state: SetProfileState) {
    return {
        ...state,
        isFetching: true,
        profile: initialState.profile,
        error: undefined as any
    }
}

function handleError(state: SetProfileState, action: Action<ErrorPayload>) {
    return {
        ...state,
        isFetching: false,
        error: action.payload.error
    }
}

function handleSuccess(state: SetProfileState, action: Action<ProfilePayload>) {
    return {
        ...state,
        isFetching: false,
        profile: action.payload.profile,
        error: undefined as any
    }
}

function handleSetProfile(state: SetProfileState, action: Action<ProfilePayload>) {
    return {
        ...state,
        profile: action.payload.profile
    }
}

function handleResetProfile(state: SetProfileState) {
    return {
        ...state,
        profile: undefined as any,
        error: undefined as any
    }
}

export default handleActions<SetProfileState>(
    {
        [PROFILE_REQUEST]: handleRequest,
        [PROFILE_ERROR]: handleError,
        [PROFILE_SUCCESS]: handleSuccess,
        [SET_PROFILE]: handleSetProfile,
        [RESET_PROFILE]: handleResetProfile
    } as any,
    initialState
)
