import {Action, handleActions} from 'redux-actions'
import { LANGUAGE_ID, ChangeLanguagePayload } from 'common/actions/lang'
import { Select } from 'common/types/Select'

export interface ChangeLanguageState {
    lang: Select
}

const initialState = {
    lang: undefined as Select
} as ChangeLanguageState

const handleChangeLanguage = (state: ChangeLanguageState, action: Action<ChangeLanguagePayload>) => {
    return {
        ...state,
        lang: action.payload
    }
}

export default handleActions<ChangeLanguageState>(
    {
        [LANGUAGE_ID]: handleChangeLanguage
    } as any,
    initialState
)