import { ProfilePage } from 'common/types/profile'

export const PROFILE_REQUEST = 'profile/REQUEST'

export function requestProfile() {
    return {
        type: PROFILE_REQUEST
    }
}

export const PROFILE_ERROR = 'profile/ERROR'

export function errorProfile(error: any) {
    return {
        type: PROFILE_ERROR,
        payload: {error}
    }
}

export const PROFILE_SUCCESS = 'profile/SUCCESS'

export interface ProfilePayload {
    profile: ProfilePage
}

export function receiveProfile(profile: ProfilePayload) {
    return {
        type: PROFILE_SUCCESS,
        payload: {profile}
    }
}

export const SET_PROFILE = 'profile/SET'

export function setProfile(profile: ProfilePage) {
    return {
        type: SET_PROFILE,
        payload: {profile}
    }
}

export const RESET_PROFILE = 'profile/RESET'

export function resetProfile() {
    return {
        type: RESET_PROFILE
    }
}