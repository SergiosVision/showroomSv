import { ProfilePage } from 'common/types/profile'

export const PROFILE_REQUEST = 'profile/REQUEST'

export function requestProfile() {
    return {
        type: PROFILE_REQUEST
    }
}

export const PROFILE_ERROR = 'profile/ERROR'

export const errorProfile = (error: any) => {
    return {
        type: PROFILE_ERROR,
        payload: {error}
    }
}

export const PROFILE_SUCCESS = 'profile/SUCCESS'

export interface ProfilePayload {
    profile: ProfilePage
}

export const receiveProfile = (profile: ProfilePayload) => {
    return {
        type: PROFILE_SUCCESS,
        payload: profile
    }
}

export const SET_PROFILE = 'profile/SET'

export const setProfile = (profile: ProfilePage) => {
    return {
        type: SET_PROFILE,
        payload: profile
    }
}

export const RESET_PROFILE = 'profile/RESET'

export const resetProfile = () => {
    return {
        type: RESET_PROFILE
    }
}

export const PROFILE_FORCE_LOAD = 'profile/FORCE_LOAD'

export const profileForceLoad = (payload: boolean) => {
    return {
        type: PROFILE_FORCE_LOAD,
        payload: payload
    }
}