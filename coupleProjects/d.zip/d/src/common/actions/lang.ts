import { Select } from 'common/types/Select'

export const LANGUAGE_ID = 'change_language/LANGUAGE_ID'

export interface ChangeLanguagePayload {
    lang: Select
}

export const changeLanguageId = (lang: ChangeLanguagePayload) => {
    return {
        type: LANGUAGE_ID,
        payload: lang
    }
}