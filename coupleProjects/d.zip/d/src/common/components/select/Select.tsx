import * as React from 'react'
import Select, {components} from 'react-select'

const cx = require('classnames/bind').bind(require('./styles/Select.scss'))

interface Props {
    options: any,
    multi?: boolean,
    clear?: boolean
    search?: boolean,
    selected?: any,
    changeEvent: (selectedOption: any) => void,
    small?: boolean,
    big?: boolean,
    full_width?: boolean,
    bold_title?: boolean,
    selectClose?: boolean,
    hideOptions?: boolean,
    className?: string,
}

export default class SelectField extends React.Component<Props, {}> {
    state = {
        selectedOption: undefined as any
    }

    render() {
        const {
            options, clear, search, changeEvent, selected, small,
            big, multi, selectClose, hideOptions, className, full_width,
            bold_title
        } = this.props

        return(
            <div className={cx('select')}>
                <Select
                    value={selected}
                    onChange={changeEvent}
                    options={options}
                    isClearable={clear}
                    isSearchable={search}
                    isMulti={multi}
                    className={cx('react-select-container', {small, big, full_width, bold_title}, className)}
                    classNamePrefix='react-select'
                    closeMenuOnSelect={selectClose}
                    hideSelectedOptions={hideOptions}
                    components={{ Option: optionItemContainer, MultiValueContainer }}
                />
            </div>
        )
    }
}

const MultiValueContainer = (props: any) => {
    return (
        <components.MultiValueLabel {...props}>
            {props.children}
            <span className={cx('sign-holder')}/>
        </components.MultiValueLabel>
    )
}

const optionItemContainer = (props: any) => {
    return (
        <components.Option {...props}>
            <span className={cx('checkbox')} />
            {props.children}
        </components.Option>
    )
}