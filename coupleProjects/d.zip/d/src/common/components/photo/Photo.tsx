import * as React from 'react'

const AddImg = require(`!svg-react-loader?name=Icon!common/icons/add.svg`)
const RemoveImg = require(`!svg-react-loader?name=Icon!common/icons/trash.svg`)

const cx = require('classnames/bind').bind(require('./styles/Photo.scss'))

interface Props {
    removeImage?: () => void,
    uploadImage?: (value: any) => void,
    editMode?: boolean,
    data?: any,
    imgUrl?: string,
    fileExtensionError?: boolean,
    fileSizeError?: boolean
}

export default class Photo extends React.Component<Props, {}> {
    render() {
        const { removeImage, editMode, imgUrl, uploadImage,
            fileExtensionError, fileSizeError, data
        } = this.props

        return (
            <div>
                <div className={cx('profile-img-holder', 'mb-15', editMode && 'profile-edit')}>
                    <div className={cx('img-holder')}>
                        {
                            data === null
                            ?
                                <img src={imgUrl}/>
                            :
                                imgUrl === undefined ? <img src={data}/> : <img src={imgUrl}/>
                        }
                    </div>
                    {
                        editMode &&
                        <div className={cx('edit-buttons-holder')}>
                            <div className={cx('add-img')}>
                                <input className={cx('file-picker')} type='file' onChange={uploadImage} />
                                <AddImg />
                            </div>
                            <div onClick={removeImage} className={cx('remove-img')}>
                                <RemoveImg />
                            </div>
                        </div>
                    }
                </div>
                {
                    fileExtensionError && <div className='mt-15 mb-15 error-message'>File must be jpeg or png type.</div>
                }
                {
                    fileSizeError && <div className='mt-15 mb-15 error-message'>Max file size 2MB</div>
                }
            </div>
        )
    }
}