import * as React from 'react'

const cx = require('classnames/bind').bind(require('./styles/LabeledItem.scss'))

interface Props {
    label: string,
    text: string,
    className?: string,
    name?: string
}

export default class LabeledItemNoForm extends React.Component<Props, {}> {
    render() {
        const  { label, text, className } = this.props

        return (
            <div className={cx('item', className)}>
                <span className={cx('title')}>{label}</span>
                     <p>{text}</p>
            </div>
        )
    }
}