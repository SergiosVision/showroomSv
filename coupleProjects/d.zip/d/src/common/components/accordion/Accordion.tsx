import * as React  from 'react'
import * as ReactDOM from 'react-dom'

const cx = require('classnames/bind').bind(require('./styles/Accordion.scss'))

interface Props {
    label: string,
    index?: number,
    classN?: string
}

export default class Accordion extends React.Component<Props, {}> {
    state = {
        height: 0,
        activeTab: 0
    }

    public componentDidMount() {
        window.setTimeout(() => {
            const el = (ReactDOM.findDOMNode(this) as Element).querySelector('.accordion-content-container')
            const height = el.scrollHeight
            this.setState({height})
        }, 333)
    }

    render() {
        const { label, index, classN } = this.props
        const { height, activeTab } = this.state
        const isActive = activeTab === index
        const innerStyle = {
            height: `${isActive ? height : 0}px`
        }

        return (
            <div className={cx('accordion', classN)}>
                <div className={cx('accordion-container')}>
                    <div
                        className={cx('accordion-activator')}
                        role='tab'
                        onClick={ () => this.activateTab(index) }
                        aria-expanded={isActive}
                    >
                        <span>{label}</span>
                    </div>
                    <div
                        className={cx('accordion-content-container')}
                        style={innerStyle}
                        aria-hidden={!isActive}
                    >
                        <div className={cx('accordion-container')}>
                            {this.props.children}
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    private activateTab = (index: number) => {
        this.setState((prev: any) => ({
            activeTab: prev.activeTab === index ? -1 : index
        }))
        this.setState((prev: any) => console.log(prev))
        console.log(this.state.activeTab)
    }
}