import * as React from 'react'
import {Field} from 'redux-form'

const cx = require('classnames/bind').bind(require('./styles/RadioButtons.scss'))

const RadioButtons = (props: any) => {
    const { icon } = props

    return (
        <div className={cx('radio-button-wrapper', props.className)}>
            <Field
                component={({input, options}) => (
                    options.map((option: any, index: number) => <div key={index} className={cx('radio-input', props.optionClassName)}>
                        <input
                            {...input}
                            id={option.id}
                            type='radio'
                            value={option.value}
                            checked={option.value === input.value}
                            onClick={props.onClick}
                            disabled={props.disabled || props.readonly}
                        />
                        <label className={cx({
                            'radio-checked': option.value === input.value,
                            disabled: props.disabled,
                            readonly: props.readonly
                        })} htmlFor={option.id}>
                            {
                                icon
                                    ?
                                        (option.label === 'Any' ? option.label : toIcon(option.label))
                                    :
                                        option.label
                            }
                        </label>
                    </div>)
                )}
                name={props.name}
                options={props.options}
            />
        </div>
    )
}

const toIcon = (value: string) => {
    const IconOutput = require(`!svg-react-loader?name=Icon!../icons/${value}.svg`)
    return (
        <IconOutput/>
    )
}

export default RadioButtons
