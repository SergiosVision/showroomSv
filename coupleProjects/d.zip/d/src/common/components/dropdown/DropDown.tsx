import * as React from 'react'
import * as ReactDOM from 'react-dom'

const cx = require('classnames/bind').bind(require('./styles/styles.scss'))

interface Props {
    button: string | JSX.Element,
    isOpen?: boolean
    className?: string
    buttonClassName?: string
    menuClassName?: string
    onClick?: () => void
}

interface State {
    isShowDropdown: boolean
}

export default class Dropdown extends React.Component<Props, State> {

    state = {
        isShowDropdown: false
    }

    componentDidMount () {
        document.addEventListener('click', this.handleDocumentClick)
    }

    componentWillUnmount () {
        document.removeEventListener('click', this.handleDocumentClick)
    }

    render() {
        const {isOpen, button, className, buttonClassName, menuClassName} = this.props

        return (
            <div className={cx('dropdown', className)} onClick={(e) => e.stopPropagation()}>
                <div ref='dropdownButton' onClick={this.handleToggleDropdown}>
                    <div className={cx('button', {'open': isOpen ? isOpen : this.state.isShowDropdown}, buttonClassName)}>
                        {button}
                    </div>
                </div>
                <menu className={cx('menu', {'show': isOpen ? isOpen : this.state.isShowDropdown}, menuClassName)}>
                    {this.props.children}
                </menu>
            </div>
        )
    }

    private handleToggleDropdown = () => {
        if (this.props.onClick) {
            this.props.onClick()
        } else {
            this.setState({...this.state,
                isShowDropdown: !this.state.isShowDropdown
            })
        }
    }

    private handleHideDropdown = () => {
        this.setState({...this.state,
            isShowDropdown: false
        })
    }

    private handleDocumentClick = (event: any) => {
        const dropdownButton = ReactDOM.findDOMNode(this.refs.dropdownButton)

        if (!!dropdownButton && !dropdownButton.contains(event.target)) {
            this.handleHideDropdown()
        }
    }
}
