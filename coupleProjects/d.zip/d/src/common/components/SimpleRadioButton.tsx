import * as React from 'react'

const cx = require('classnames/bind').bind(require('./styles/SimpleRadioButton.scss'))

const RadioButtons = (props: any) => {
    const { input, data, labelText, checked, className } = props

    return (
        <div className={cx('simple-radio', className)}>
            <input
                {...input}
                type='radio'
                value={data}
                id={data}
                defaultChecked={checked}
            />
            <label htmlFor={data}>
                <span className={cx('circle')}/>
                {labelText && labelText}
            </label>
        </div>
    )
}

export default RadioButtons
