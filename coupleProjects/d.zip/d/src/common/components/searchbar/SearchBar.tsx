import * as React from 'react'

const cx = require('classnames/bind').bind(require('./styles/Searchbar.scss'))

interface Props {
    placeholder?: string,
    icon?: string,
    iconClass?: string,
    changeEvent: (e: any) => void,
    submitEvent: () => void,
    onKeyDownEvent: (e: any) => void,
    className?: string
}

export default class SearchBar extends React.Component<Props, {}> {
    render() {
        const {
            placeholder, icon, iconClass,
            changeEvent, submitEvent, onKeyDownEvent,
            className
        } = this.props
        const Search = icon && require(`!svg-react-loader?name=Icon!common/icons/${icon}.svg`)

        return (
            <div className={cx('searchbar', {className})}>
                <input
                    type='text'
                    placeholder={placeholder}
                    onChange={changeEvent}
                    onKeyDown={onKeyDownEvent}
                />
                {
                    icon && <Search onClick={submitEvent} className={cx('searchbar-icon', {iconClass})}/>
                }
            </div>
        )
    }
}