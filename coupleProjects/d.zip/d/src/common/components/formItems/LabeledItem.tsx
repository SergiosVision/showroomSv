import * as React from 'react'
import {BaseFieldProps, WrappedFieldProps} from 'redux-form'

const cx = require('classnames/bind').bind(require('./styles/LabeledItem.scss'))

interface Props {
    label: string,
    text?: string,
    editable?: boolean,
    editMode?: boolean,
    className?: string,
    name?: string,
    type: string,
    small?: boolean,
    big?: boolean,
    disabledLabel?: boolean
}

export default class LabeledItem extends React.Component<BaseFieldProps & WrappedFieldProps & React.InputHTMLAttributes<HTMLFormElement> & Props> {
    render() {
        const  {
            label, text, editable, editMode, className,
            input, type, meta, small, big, disabledLabel
        } = this.props

        return (
            <div className={cx('item', className, {small, big})}>
                {
                    !disabledLabel && <span className={cx('title')}>{label}</span>
                }
                {
                    !editMode && <p>{text}</p>
                }
                {
                    editable && editMode && <input type={type} {...input} />
                }
                {meta.touched && ((meta.error && <div className={cx('error')}>{meta.error}</div>))}
            </div>
        )
    }
}