import * as React from 'react'
import {BaseFieldProps, WrappedFieldProps} from 'redux-form'

const cx = require('classnames/bind').bind(require('./styles/Checkbox.scss'))

interface Props {
    label?: string,
    count?: number
}

export default class Checkbox extends React.Component<BaseFieldProps & WrappedFieldProps & React.InputHTMLAttributes<HTMLFormElement> & Props> {
    render() {
        const { label, name, input, count } = this.props

        return (
            <div className={cx('checkbox')}>
                <label htmlFor={name} className={cx('checkbox-label')}>
                    {`${label} ${count === undefined ? '' : `(${count})`}`}
                    <input id={name} type='checkbox' checked={input.value} {...input}/>
                    <span className={cx('custom-box')}/>
                </label>
            </div>
        )
    }
}