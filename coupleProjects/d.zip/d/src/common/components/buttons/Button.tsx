import * as React from 'react'

const cx = require('classnames/bind').bind(require('./styles/button.scss'))

interface Props {
    type?: string,
    className?: string
    onClick?: () => void
    disabled?: boolean
    cancel?: boolean,
    red?: boolean,
    fixedWidth?: boolean,
    id?: string,
    fill_red?: boolean
}

export default class Button extends React.Component<Props, {}> {
    render() {
        const { onClick, className, type, cancel, fixedWidth, id, red, fill_red, disabled} = this.props

        return (
            <button
                type={type}
                id={id}
                disabled={disabled}
                className={cx('button', className, {cancel, fixedWidth, red, fill_red})}
                onClick={onClick}
            >
                {this.props.children}
            </button>
        )
    }
}
