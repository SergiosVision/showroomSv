import { ProfilePage } from 'common/types/profile'

export interface UserPayload {
    user: ProfilePage
}

export const SET_ACCESS_TOKEN = 'sign_in_form/SET_ACCESS_TOKEN'

export const setAccessToken = (accessToken: string) => {
    return {
        type: SET_ACCESS_TOKEN,
        payload: accessToken
    }
}

export const SET_USER = 'user/SET'

export const setUser = (user: ProfilePage) => {
    return {
        type: SET_USER,
        payload: user
    }
}

export const RESET_USER = 'user/RESET'

export const resetUser = () => {
    return {
        type: RESET_USER
    }
}