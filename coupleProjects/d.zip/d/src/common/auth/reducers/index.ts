import {Action, handleActions} from 'redux-actions'

const cookie = require('react-cookies')

import {
    SET_ACCESS_TOKEN,
    SET_USER,
    RESET_USER,
    UserPayload
} from '../actions'

export interface AuthState {
    accessToken: string,
    user: UserPayload
}

const initialState = <AuthState> {
    accessToken: cookie.load('accessToken'),
    user: undefined as UserPayload
}

export interface AccessTokenPayload {
    accessToken: string
}

const handleSetAccessToken = (state: AuthState, action: Action<AccessTokenPayload>) => {
    return {
        ...state,
        accessToken: action.payload.accessToken
    }
}

const handleSetUser = (state: AuthState, action: Action<UserPayload>) => {
    return {
        ...state,
        user: action.payload
    }
}

const handleResetUser = (state: AuthState) => {
    return {
        ...state,
        user: undefined as UserPayload,
        accessToken: undefined as string
    }
}

export default handleActions<AuthState>(
    {
        [SET_ACCESS_TOKEN]: handleSetAccessToken,
        [SET_USER]: handleSetUser,
        [RESET_USER]: handleResetUser
    } as any,
    initialState
)