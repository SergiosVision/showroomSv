export enum Proof {
    Signature = 1,
    Photo = 2,
    Payment = 3
}