export enum Payment {
    Cash = 1,
    Check = 2,
    Card = 3
}