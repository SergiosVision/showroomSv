export enum Notification {
    SMS = 1,
    Email = 2
}