export enum Vehicle {
    Any = 1,
    Motorcycle = 2,
    Car = 3,
    Truck = 4
}