import * as React from 'react'
import {connect, DispatchProp} from 'react-redux'
import {InjectedFormProps, reduxForm} from 'redux-form'
import axios, {AxiosError, AxiosResponse} from 'axios'

import {history} from 'store'
import {State} from 'reducers'

import { Notification } from 'common/enums/notification'
import { Payment } from 'common/enums/payment'
import { Proof } from 'common/enums/proof'
import { Vehicle } from 'common/enums/vehicle'

import {
    hideSubmitLoader,
    setFormError,
    showSubmitLoader
} from '../actions'
import { changeAddress } from '../actions/fnbAddress'


import TopSection from '../components/TopSection'
import NewOrder from '../components/NewOrder'

interface FormProps {
    id: string,
    phone: string,
    first_name: string,
    last_name: string,
    email: string,
    destination: number,
    customer_notification_type: Notification,
    proof_of_delivery: Proof,
    payment_type: string,
    vehicle_type: string,
    amount: string,
    notes: string
}

interface Props {
    errorMessage: string,
    isShowSubmitLoader: boolean,
    destination: any
    addressId: number
}

interface DispatchProps {
    showSubmitLoader: () => void,
    hideSubmitLoader: () => void,
    setFormError: (error: any) => void
    changeAddress: (id: number) => void
}

class NewOrderContainer extends React.Component<Props & DispatchProps & DispatchProp<{}> & InjectedFormProps<FormProps>> {
    state = {
        notificationValue: { value: '1', label: 'SMS' },
        proofValue: { value: '1', label: 'Signature' },
        tasksValue: { value: '1', label: 'Tell about discounts' }
    }

    componentWillMount() {
        const { initialize } = this.props

        initialize({
            payment_type: '1',
            vehicle_type: '1'
        })
    }

    render() {
        const { handleSubmit, isShowSubmitLoader } = this.props
        const { notificationValue, proofValue, tasksValue } = this.state

        return (
           <div>
               <TopSection
                    saveAndAssign={handleSubmit(this.saveAndAssign)}
                    isShowSubmitLoader={isShowSubmitLoader}
               />
               <NewOrder
                    handleNotificationEvent={this.handleChangeNotification}
                    notificationValue={notificationValue}
                    handleProofEvent={this.handleChangeProof}
                    proofValue={proofValue}
                    handleTasksEvent={this.handleChangeTasks}
                    tasksValue={tasksValue}
                    saveAndAssign={handleSubmit(this.saveAndAssign)}
               />
           </div>
        )
    }

    private handleChangeNotification = (selectedOption: any) => {
        this.setState({ notificationValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({notificationValue: { value: '1', label: 'SMS' }})
        }
    }

    private handleChangeProof = (selectedOption: any) => {
        this.setState({ proofValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({proofValue: { value: '1', label: 'Signature' }})
        }
    }

    private handleChangeTasks = (selectedOption: any) => {
        this.setState({ tasksValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({tasksValue: { value: '1', label: 'Tell about discounts' }})
        }
    }


    private saveAndAssign = (values: FormProps) => {
        const { setFormError, showSubmitLoader, hideSubmitLoader  } = this.props
        const { notificationValue, proofValue, tasksValue } = this.state
        console.log(notificationValue)

        // console.log((notificationValue as Array<object>).reduce((accumulator: number, obj: object) => accumulator & (obj.value, 0))

        let sms = 1
        let email = 2

        // console.log(values.destination)
        //
        // this.props.changeAddress(values.destination)
        //
        // setTimeout(() => console.log(values.destination, this.props.addressId), 0)

        const data = {
            customer: {
                id: values.id,
                first_name: values.first_name,
                last_name: '',
                email: values.email,
                phone: values.phone
            },
            customer_notification_type: sms & email,
            destination: {
                area: 'Hawalli',
                block: 1,
                street: 'Abu Dhabi St',
                jadda: 1,
                building: '1a',
                floor: 1,
                apartment: 1,
                latitude: parseFloat('83.21832'),
                longitude: parseFloat('72.18623')

            },
            proof_of_delivery: 1,
            tasks: 1,
            amount: parseFloat(values.amount),
            notes: values.notes,
            payment_type: parseInt(values.payment_type),
            vehicle_type: parseInt(values.vehicle_type)

        }
        console.log(data)

        // showSubmitLoader()

        axios
            .post(`${process.env.SERVICE_URL}/fnb/orders`, data)
            .then(() => {
                setFormError('')
                hideSubmitLoader()
                history.push('/')
            })
            .catch(
                (error: AxiosError) => {
                    setFormError(error.response.data.message)
                }
            )

    }
}

const validate = (values: FormProps) => {
    const errors = {} as any
    const requiredMessage = 'This field is required.'

    if (!values.id) {
        errors.id = requiredMessage
    }

    if (!values.phone) {
        errors.phone = requiredMessage
    }

    if (!values.first_name) {
        errors.first_name = requiredMessage
    }

    return errors
}

const NewOrderReduxeForm = reduxForm({
    form: 'newOrderForm',
    validate
})(NewOrderContainer)

const mapStateToProps = (state: State) => {
    return {
        isShowSubmitLoader: state.newOrderForm.isShowSubmitLoader,
        errorMessage: state.newOrderForm.errorMessage,
        addressId: state.newOrderForm.addressId
    }
}

export default connect(
    mapStateToProps,
    {
        setFormError,
        showSubmitLoader,
        hideSubmitLoader,
        changeAddress
    }
)(NewOrderReduxeForm as any)