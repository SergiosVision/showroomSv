import * as React from 'react'
import {connect, DispatchProp} from 'react-redux'
import {InjectedFormProps, reduxForm} from 'redux-form'
import axios, {AxiosError, AxiosResponse} from 'axios'

import {history} from 'store'
import {State} from 'reducers'
import {
    hideSubmitLoader,
    setFormError,
    showSubmitLoader,
    requestAddress,
    successAddressRequest
} from '../actions'
import { changeAddress } from '../actions/fnbAddress'
import { CustomerAddress } from 'common/types/FNB/CustomerAddress'
import { SelectData } from 'common/types/SelectData'

import TopSection from '../components/TopSection'
import NewOrder from '../components/NewOrder'

const cookie = require('react-cookies')

interface FormProps {
    id: string,
    phone: string,
    first_name: string,
    last_name: string,
    email: string,
    destination: number,
    customer_notification_type: number,
    proof_of_delivery: number,
    payment_type: string,
    vehicle_type: string,
    amount: string,
    notes: string
}

interface Props {
    errorMessage: string,
    isShowSubmitLoader: boolean,
    destination: any
    addressId: number,
    addresses: CustomerAddress[]
}

interface DispatchProps {
    showSubmitLoader: () => void,
    hideSubmitLoader: () => void,
    setFormError: (error: any) => void
    changeAddress: (id: number) => void,
    requestAddress: () => void,
    successAddressRequest: (address: CustomerAddress[]) => void
}

class NewOrderContainer extends React.Component<Props & DispatchProps & DispatchProp<{}> & InjectedFormProps<FormProps>> {
    state = {
        notificationValue: [{ value: '1', label: 'SMS' }],
        proofValue: [{ value: '1', label: 'Signature' }],
        tasksValue: [{ value: '1', label: 'Tell about discounts' }]
    }

    componentWillMount() {
        const { initialize, requestAddress, successAddressRequest } = this.props

        const placeHolderData = [
            {
                area: 'Hawalli',
                block: 1,
                street: 'Abu Dhabi St',
                jadda: 1,
                building: '1a',
                floor: 1,
                apartment: 1,
                latitude: 3232,
                longitude: 3232
            },
            {
                area: 'Ahmadi',
                block: 4,
                street: 'Abu Dabhi St',
                jadda: 0,
                building: '28',
                floor: 7,
                apartment: 108,
                latitude: 3232,
                longitude: 3232
            },
            {
                area: 'Jahra',
                block: 1,
                street: 'Airport Rd',
                jadda: 0,
                building: '888',
                floor: 250,
                apartment: 55,
                latitude: 3232,
                longitude: 3232
            }
        ]

        requestAddress()

        successAddressRequest(placeHolderData)

        initialize({
            payment_type: '1',
            vehicle_type: '1'
        })
    }

    render() {
        const { handleSubmit, isShowSubmitLoader, addresses } = this.props
        const { notificationValue, proofValue, tasksValue } = this.state

        return (
           <div>
               <TopSection
                    saveAndAssign={handleSubmit(this.saveAndAssign)}
                    isShowSubmitLoader={isShowSubmitLoader}
               />
               <NewOrder
                    handleNotificationEvent={this.handleChangeNotification}
                    notificationValue={notificationValue}
                    handleProofEvent={this.handleChangeProof}
                    proofValue={proofValue}
                    handleTasksEvent={this.handleChangeTasks}
                    tasksValue={tasksValue}
                    saveAndAssign={handleSubmit(this.saveAndAssign)}
                    handlePhoneChange={this.handleSearch}
                    addresses={addresses}
               />
           </div>
        )
    }

    private handleChangeNotification = (selectedOption: any) => {
        this.setState({ notificationValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({notificationValue: [{ value: '1', label: 'SMS' }]})
        }
    }

    private handleChangeProof = (selectedOption: any) => {
        this.setState({ proofValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({proofValue: [{ value: '1', label: 'Signature' }]})
        }
    }

    private handleChangeTasks = (selectedOption: any) => {
        this.setState({ tasksValue: selectedOption })

        if (selectedOption.length === 0) {
            this.setState({tasksValue: [{ value: '1', label: 'Tell about discounts' }]})
        }
    }

    private handleSearch = (e: any) => {
        if (e.target.value.length > 5) {
            axios
                .get(`${process.env.SERVICE_URL}/customers/search?phone=${e.target.value}`, {
                    headers: { Authorization: cookie.load('accessToken')}
                } )
                .then((response: AxiosResponse) => {
                    console.log(response.data)
                })
                .catch(
                    (error: AxiosError) => {}
                )
        }
    }

    private convertToBitMask = (value: SelectData[]) => {
        let arr: Array<number> = []

        value.map(item => {
            arr.push(parseInt(item.value))
        })

        return arr.reduce((accumulator, curVal) => accumulator | (curVal))
    }

    private saveAndAssign = (values: FormProps) => {
        const { setFormError, showSubmitLoader, hideSubmitLoader, addressId, addresses  } = this.props
        const { notificationValue, proofValue, tasksValue } = this.state

        const data = {
            customer: {
                id: values.id,
                first_name: values.first_name,
                last_name: '',
                email: values.email,
                phone: values.phone
            },
            customer_notification_type: this.convertToBitMask(notificationValue),
            destination: addresses[values.destination],
            proof_of_delivery: this.convertToBitMask(proofValue),
            tasks: this.convertToBitMask(tasksValue),
            amount: parseFloat(values.amount),
            notes: values.notes,
            payment_type: parseInt(values.payment_type),
            vehicle_type: parseInt(values.vehicle_type)

        }
        console.log(data)

        showSubmitLoader()

        axios
            .post(`${process.env.SERVICE_FNB}/orders`, data)
            .then((response: AxiosResponse) => {
                setFormError('')
                hideSubmitLoader()
                console.log(response.data)
                history.push('/')
            })
            .catch(
                (error: AxiosError) => {
                    hideSubmitLoader()
                    setFormError(error.response.data.message)
                }
            )
    }
}

const validate = (values: FormProps) => {
    const errors = {} as any
    const requiredMessage = 'This field is required.'

    if (!values.id) {
        errors.id = requiredMessage
    }

    if (!values.phone) {
        errors.phone = requiredMessage
    }

    if (!values.first_name) {
        errors.first_name = requiredMessage
    }

    if (!values.amount) {
        errors.amount = requiredMessage
    }

    return errors
}

const NewOrderReduxeForm = reduxForm({
    form: 'newOrderForm',
    validate
})(NewOrderContainer)

const mapStateToProps = (state: State) => {
    return {
        isShowSubmitLoader: state.newOrderForm.isShowSubmitLoader,
        errorMessage: state.newOrderForm.errorMessage,
        addressId: state.newOrderForm.addressId,
        addresses: state.newOrderForm.addresses
    }
}

export default connect(
    mapStateToProps,
    {
        setFormError,
        showSubmitLoader,
        hideSubmitLoader,
        changeAddress,
        requestAddress,
        successAddressRequest
    }
)(NewOrderReduxeForm as any)