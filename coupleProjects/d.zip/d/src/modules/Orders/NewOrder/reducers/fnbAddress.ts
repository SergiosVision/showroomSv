import {Action} from 'redux-actions'
import {NewOrderFormState} from './index'
import { ChangeAddressPayload } from '../actions/fnbAddress'

export function handleChangeAddress(state: NewOrderFormState, action: Action<ChangeAddressPayload>) {
    return {...state,
        addressId: action.payload.id
    }
}
