import {Action, handleActions} from 'redux-actions'

import {ErrorPayload} from 'common/payloads/ErrorActionPayload'
import {
    HIDE_SUBMIT_LOADER,
    SET_NEW_ORDER_ERROR,
    SHOW_SUBMIT_LOADER,
    ADDRESS_REQUEST,
    ADDRESS_SUCCESS,
    AddressPayload
} from '../actions'
import {CHANGE_ADDRESS} from '../actions/fnbAddress'
import {handleChangeAddress} from './fnbAddress'
import { CustomerAddress } from 'common/types/FNB/CustomerAddress'

export interface NewOrderFormState {
    isShowSubmitLoader: boolean
    errorMessage: string
    addressId: number,
    addresses: CustomerAddress[]
}

const initialState = <NewOrderFormState>{
    isShowSubmitLoader: false,
    errorMessage: undefined as string,
    addressId: 0,
    addresses: undefined,
    isFetching: false
}

function handleShowSubmitLoader(state: NewOrderFormState) {
    return {...state,
        isShowSubmitLoader: true
    }
}

function handleHideSubmitLoader(state: NewOrderFormState) {
    return {...state,
        isShowSubmitLoader: false
    }
}

function handleError(state: NewOrderFormState, action: Action<ErrorPayload>) {
    return {
        ...state,
        errorMessage: action.payload.error
    }
}

const handleRequestAddress = (state: NewOrderFormState) => {
    return {
        ...state,
        isFetching: false,
        addresses: initialState.addresses
    }
}

const handleSuccessRequestAddress = (state: NewOrderFormState, action: Action<AddressPayload>) => {
    return {
        ...state,
        isFetching: false,
        addresses: action.payload,
        errorMessage: undefined as any
    }
}

export default handleActions<NewOrderFormState>(
    {
        [CHANGE_ADDRESS]: handleChangeAddress,
        [SET_NEW_ORDER_ERROR]: handleError,
        [SHOW_SUBMIT_LOADER]: handleShowSubmitLoader,
        [HIDE_SUBMIT_LOADER]: handleHideSubmitLoader,
        [ADDRESS_REQUEST]: handleRequestAddress,
        [ADDRESS_SUCCESS]: handleSuccessRequestAddress
    } as any,
    initialState
)
