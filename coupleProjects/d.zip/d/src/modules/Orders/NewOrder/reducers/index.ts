import {Action, handleActions} from 'redux-actions'

import {ErrorPayload} from 'common/payloads/ErrorActionPayload'
import {HIDE_SUBMIT_LOADER, SET_NEW_ORDER_ERROR, SHOW_SUBMIT_LOADER} from '../actions'
import {CHANGE_ADDRESS} from '../actions/fnbAddress'
import {handleChangeAddress} from './fnbAddress'

export interface NewOrderFormState {
    isShowSubmitLoader: boolean
    errorMessage: string
    addressId: number
}

const initialState = <NewOrderFormState>{
    isShowSubmitLoader: false,
    errorMessage: undefined as string,
    addressId: 0
}

function handleShowSubmitLoader(state: NewOrderFormState) {
    return {...state,
        isShowSubmitLoader: true
    }
}

function handleHideSubmitLoader(state: NewOrderFormState) {
    return {...state,
        isShowSubmitLoader: false
    }
}

function handleError(state: NewOrderFormState, action: Action<ErrorPayload>) {
    return {
        ...state,
        errorMessage: action.payload.error
    }
}

export default handleActions<NewOrderFormState>(
    {
        [CHANGE_ADDRESS]: handleChangeAddress,
        [SET_NEW_ORDER_ERROR]: handleError,
        [SHOW_SUBMIT_LOADER]: handleShowSubmitLoader,
        [HIDE_SUBMIT_LOADER]: handleHideSubmitLoader
    } as any,
    initialState
)
