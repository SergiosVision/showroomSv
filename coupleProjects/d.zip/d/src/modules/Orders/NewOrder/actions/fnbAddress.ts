export const CHANGE_ADDRESS = 'change_address/CHANGE_ADDRESS'

export interface ChangeAddressPayload {
    id: number
}

export const changeAddress = (id: number) => {
    return {
        type: CHANGE_ADDRESS,
        payload: { id }
    }
}