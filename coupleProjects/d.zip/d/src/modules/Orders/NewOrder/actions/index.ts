import { CustomerAddress } from 'common/types/FNB/CustomerAddress'

export interface AddressPayload {
    addresses: CustomerAddress[]
}

export const SHOW_SUBMIT_LOADER = 'new_order/SHOW_SUBMIT_LOADER'

export const showSubmitLoader = () => {
    return {
        type: SHOW_SUBMIT_LOADER
    }
}

export const HIDE_SUBMIT_LOADER = 'new_order/HIDE_SUBMIT_LOADER'

export const hideSubmitLoader = () => {
    return {
        type: HIDE_SUBMIT_LOADER
    }
}

export const SET_NEW_ORDER_ERROR = 'new_order/ERROR'

export const setFormError = (error: any) => {
    return {
        type: SET_NEW_ORDER_ERROR,
        payload: {error}
    }
}

export const ADDRESS_REQUEST = 'customer_address/REQUEST'

export const requestAddress = () => {
    return {
        type: ADDRESS_REQUEST
    }
}

export const ADDRESS_SUCCESS = 'customer_address/SUCCESS'

export const successAddressRequest = (address: CustomerAddress) => {
    return {
        type: ADDRESS_SUCCESS,
        payload: address
    }
}
