import * as React from 'react'
import {Route, Switch, RouteComponentProps, Link} from 'react-router-dom'

import NewOrderContainer from 'modules/Orders/NewOrder/containers/NewOrderContainer'

class Orders extends React.Component<RouteComponentProps<{}>> {
    render() {
        return (
            <div>
                <Switch>
                    <Route exact path={`${this.props.match.path}/`} component={NewOrderContainer} />
                </Switch>
            </div>
        )
    }
}

export default Orders