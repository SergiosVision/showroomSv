import axios, {AxiosResponse} from 'axios'
import {store} from 'store'

import {State} from 'reducers'
import {errorProfile, receiveProfile, requestProfile} from 'common/actions/setProfile'
import {ProfilePage} from 'common/types/profile'

const cookie = require('react-cookies')

export default class PartnerReceiver {
    public receive(handleSuccess: (profile: ProfilePage) => void) {
        const dispatch = store.dispatch
        const state = store.getState() as State
        if (!state.setProfile.profile) {
            dispatch(requestProfile())
            axios
                .get(`${process.env.SERVICE_URL}/profile`, {
                    headers: { Authorization: cookie.load('accessToken')}
                })
                .then(
                    (json: AxiosResponse) => {
                        dispatch(receiveProfile(json.data.user))
                        handleSuccess(json.data.user)
                    }
                )
                .catch(
                    (error) => dispatch(errorProfile(error))
                )
        } else {
            handleSuccess(state.setProfile.profile)
        }
    }
}
