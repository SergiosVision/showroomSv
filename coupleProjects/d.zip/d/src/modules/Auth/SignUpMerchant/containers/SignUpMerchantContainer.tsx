import * as React from 'react'
import {connect, DispatchProp} from 'react-redux'
import {InjectedFormProps, reduxForm} from 'redux-form'
import axios, {AxiosError, AxiosResponse} from 'axios'

import {history} from 'store'
import {State} from 'reducers'

import {
    hideSubmitLoader,
    setSignUpMerchantError,
    showSubmitLoader
} from '../actions'

import SignUpMerchantForm from 'modules/Auth/SignUpMerchant/components/SignUpMerchantForm'

const cookie = require('react-cookies')

interface FormProps {
    email: string,
    password: string,
    repeatPassword: string,
    business_type: number
}

interface Props extends InjectedFormProps<FormProps> {
    errorMessage: string,
    isShowSubmitLoader: boolean,
}

interface DispatchProps {
    setSignUpMerchantError: (errorMessage: string) => void,
    showSubmitLoader: () => void,
    hideSubmitLoader: () => void,
}

class SignUpMerchantContainer extends React.Component<Props & DispatchProps & DispatchProp<{}>> {
    componentWillMount() {
        const { initialize } = this.props

        initialize({
            business_type: 1
        })
    }

    render() {
        const {handleSubmit, errorMessage, isShowSubmitLoader} = this.props

        return (
            <SignUpMerchantForm
                submitForm={handleSubmit(this.submitForm)}
                errorMessage={errorMessage}
                isShowSubmitLoader={isShowSubmitLoader}
            />
        )
    }

    private submitForm = (values: FormProps) => {
        const { email, password, business_type } = values
        console.log(values)

        this.props.showSubmitLoader()

        axios
            .post(`${process.env.SERVICE_URL}/auth/sign-up/merchant`, {
                email: email.trim(),
                password: password.trim(),
                type: business_type
            })
            .then((response: AxiosResponse) => {
                this.props.hideSubmitLoader()

                console.log(response)

                history.push('/auth')
            })
            .catch(
                (error: AxiosError) => {
                    this.props.hideSubmitLoader()
                    console.log(error)
                    this.props.setSignUpMerchantError(error.response.data.message)
                }
            )
    }
}

const validate = (values: FormProps) => {
    const errors = {} as any
    const requiredMessage = 'This field is required.'

    if (!values.email) {
        errors.email = requiredMessage
    }

    if (!values.password) {
        errors.password = requiredMessage
    } else if (values.password !== values.repeatPassword) {
        errors.password = 'Passwords do not match'
    }

    if (!values.repeatPassword) {
        errors.repeatPassword = requiredMessage
    } else if (values.password !== values.repeatPassword) {
        errors.repeatPassword = 'Passwords do not match'
    }

    return errors
}

const SignUpMerchantReduxForm = reduxForm({
    form: 'SignUpMerchantContainer',
    validate
})(SignUpMerchantContainer)

const mapStateToProps = (state: State) => {
    return {
        errorMessage: state.signUpMerchantForm.errorMessage,
        isShowSubmitLoader: state.signUpMerchantForm.isShowSubmitLoader
    }
}

export default connect(
    mapStateToProps,
    {
        setSignUpMerchantError,
        showSubmitLoader,
        hideSubmitLoader
    }
)(SignUpMerchantReduxForm as any)