import * as React from 'react'
import {InitialMenu} from 'common/types/initialMenu'

const cx = require('classnames/bind').bind(require('./styles/styles.scss'))

import LinkItem from 'common/components/LinkItem'

interface Props {
    initialMenu: InitialMenu[]
}

class SideBar extends React.Component<Props> {

    render() {
        const { initialMenu } = this.props

        return (
            <nav>
                <ul>
                    {
                        initialMenu.map((item , index) => {
                              return (
                                  <li key={index}>
                                      <LinkItem icon={item.singlePath} routePath={`/${item.singlePath}`} text={item.singlePath} />
                                  </li>
                              )
                        })
                    }
                </ul>
            </nav>
        )
    }
}

export default SideBar
