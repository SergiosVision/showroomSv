import { ProfilePayload } from 'common/payloads/ProfilePayload'

export const NEW_ORDER_REQUEST = 'new_order/REQUEST'

export const requestNewOrder = () => {
    return {
        type: NEW_ORDER_REQUEST
    }
}

export const NEW_ORDER_ERROR = 'new_order/ERROR'

export const errorNewOrder = (error: any) => {
    return {
        type: NEW_ORDER_ERROR,
        payload: {error}
    }
}

export const NEW_ORDER_SUCCESS = 'new_order/SUCCESS'

export function newOrderReceive(payload: ProfilePayload) {
    return {
        type: NEW_ORDER_SUCCESS,
        payload: payload
    }
}