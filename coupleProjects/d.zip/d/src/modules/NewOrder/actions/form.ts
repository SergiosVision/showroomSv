export const SHOW_SUBMIT_LOADER = 'new_order/SHOW_SUBMIT_LOADER'

export const showSubmitLoader = () => {
    return {
        type: SHOW_SUBMIT_LOADER
    }
}

export const HIDE_SUBMIT_LOADER = 'new_order/HIDE_SUBMIT_LOADER'

export const hideSubmitLoader = () => {
    return {
        type: HIDE_SUBMIT_LOADER
    }
}

export const SET_NEW_ORDER_ERROR = 'new_order/ERROR'

export function setNewOrderUpdateError(error: string) {
    return {
        type: SET_NEW_ORDER_ERROR,
        payload: {error}
    }
}
