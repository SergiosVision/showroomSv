module.exports = {
    path: {
        app: 'https://api.dev.dizli.net/app/v1',
        fnb: 'https://api.dizli.net/fnb/v1'
    },
    env: 'build',
    cacheBoosting: false
};
