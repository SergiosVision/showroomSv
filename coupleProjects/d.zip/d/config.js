module.exports = {
    path: 'https://api.dev.dizli.net/app/v1',
    env: 'development',
    cacheBoosting: false
};
