module.exports = {
    path: 'https://api.dizli.net/v1/app',
    env: 'development',
    cacheBoosting: false
};
