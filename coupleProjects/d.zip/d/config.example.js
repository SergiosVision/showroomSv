module.exports = {
    path: {
        app: 'https://api.dev.dizli.net',
    },
    env: 'development',
    cacheBoosting: false
};
