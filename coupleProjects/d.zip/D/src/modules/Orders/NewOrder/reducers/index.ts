import {Action, handleActions} from 'redux-actions'

import {ErrorPayload} from 'common/payloads/ErrorActionPayload'
import {HIDE_SUBMIT_LOADER, SET_NEW_ORDER_ERROR, SHOW_SUBMIT_LOADER} from '../actions'

export interface NewOrderFormState {
    isShowSubmitLoader: boolean,
    errorMessage: string
}

const initialState = <NewOrderFormState>{
    isShowSubmitLoader: false,
    errorMessage: undefined as string
}

function handleShowSubmitLoader(state: NewOrderFormState) {
    return {...state,
        isShowSubmitLoader: true
    }
}

function handleHideSubmitLoader(state: NewOrderFormState) {
    return {...state,
        isShowSubmitLoader: false
    }
}

function handleError(state: NewOrderFormState, action: Action<ErrorPayload>) {
    return {
        ...state,
        errorMessage: action.payload.error
    }
}

export default handleActions<NewOrderFormState>(
    {
        [SET_NEW_ORDER_ERROR]: handleError,
        [SHOW_SUBMIT_LOADER]: handleShowSubmitLoader,
        [HIDE_SUBMIT_LOADER]: handleHideSubmitLoader
    } as any,
    initialState
)
