import * as React from 'react'
import {Field} from 'redux-form'

import LabeledItem from 'common/components/LabeledItem'
import RadioButtons from 'common/components/RadioButton'
import SelectField from 'common/components/Select/Select'
import MultipleSelector from 'common/components/MultipleSelector/MultipleSelector'

const cx = require('classnames/bind').bind(require('../styles/styles.scss'))

interface Props {
    handleNotificationEvent: (selectedOption: any) => void,
    notificationValue: object,
    handleProofEvent: (selectedOption: any) => void,
    proofValue: object,
    handleTasksEvent: (selectedOption: any) => void,
    tasksValue: object
}

export default class NewOrder extends React.Component<Props, {}> {
    render() {
        const { handleNotificationEvent, notificationValue, handleProofEvent, proofValue, handleTasksEvent, tasksValue } = this.props

        return (
            <div className='row'>
                <div className={cx('bg-white', 'pl-40 column s-12', 'container-height', 'content-container')}>
                    <form className={cx('mt-20', 'content-holder')}>
                        <div className={cx('customer-info')}>
                            <Field
                                name='id'
                                type='text'
                                label='Order ID*'
                                editable={true}
                                editMode={true}
                                component={LabeledItem}
                            />
                            <Field
                                name='phone'
                                type='tel'
                                label='Customer Phone Number*'
                                editable={true}
                                editMode={true}
                                component={LabeledItem}
                            />
                            <div className={cx('customer-row-info')}>
                                <Field
                                    name='first_name'
                                    type='text'
                                    label='Customer Name*'
                                    editable={true}
                                    editMode={true}
                                    component={LabeledItem}
                                    className='mb-0'
                                />
                                <Field
                                    name='email'
                                    type='email'
                                    label='Customer E-mail'
                                    editable={true}
                                    editMode={true}
                                    component={LabeledItem}
                                    className='mb-0 ml-40'
                                />
                            </div>
                        </div>
                        {/*table*/}
                        <div className={cx('bottom-info', 'mt-40')}>
                            <div className={cx('sides-holder')}>
                                <div className={cx('left-side')}>
                                    <div className={cx('paymaent-type', 'mb-20')}>
                                        <span className={cx('small-title')}>Payment Type</span>
                                        <RadioButtons name='payment_type' options={[
                                            {
                                                id: 'cash',
                                                label: 'Cash on Delivery',
                                                value: '1'
                                            },
                                            {
                                                id: 'paid',
                                                label: 'Paid',
                                                value: '2'
                                            }
                                        ]}
                                        />
                                    </div>
                                    <div className={cx('tasks')}>
                                        <span className={cx('small-title')}>Tasks</span>
                                        <MultipleSelector />
                                        {/*<SelectField*/}
                                            {/*multi={true}*/}
                                            {/*clear={false}*/}
                                            {/*search={false}*/}
                                            {/*changeEvent={handleTasksEvent}*/}
                                            {/*selected={tasksValue}*/}
                                            {/*options={[*/}
                                                {/*{ value: '1', label: 'Signature' },*/}
                                                {/*{ value: '2', label: 'Photo' },*/}
                                                {/*{ value: '4', label: 'Payment' }*/}
                                            {/*]}*/}
                                        {/*/>*/}
                                    </div>
                                    <div className={cx('vehicle-type', 'mt-20')}>
                                        <span className={cx('small-title')}>Payment Type</span>
                                        <RadioButtons name='vehicle_type' icon options={[
                                            {
                                                id: 'any',
                                                label: 'Any',
                                                value: '1'
                                            },
                                            {
                                                id: 'motorcycle',
                                                label: 'motorcycle',
                                                value: '2'
                                            },
                                            {
                                                id: 'vehicle',
                                                label: 'vehicle',
                                                value: '3'
                                            },
                                            {
                                                id: 'truck',
                                                label: 'truck',
                                                value: '4'
                                            }
                                        ]}
                                        />
                                    </div>
                                </div>
                                <div className={cx('right-side')}>
                                    <div className={cx('top-side')}>
                                        <div className={cx('amount')}>
                                            <Field
                                                name='amount'
                                                type='text'
                                                label='Amount'
                                                small
                                                editable={true}
                                                editMode={true}
                                                component={LabeledItem}
                                            />
                                        </div>
                                        <div className={cx('notification-type')}>
                                            <span className={cx('small-title')}>Customer Notification</span>
                                            <SelectField
                                                clear={false}
                                                search={false}
                                                changeEvent={handleNotificationEvent}
                                                selected={notificationValue}
                                                small
                                                options={[
                                                    { value: '1', label: 'SMS' },
                                                    { value: '2', label: 'Email' }
                                                ]}
                                            />
                                        </div>
                                    </div>
                                    <div className={cx('bottom-side')}>
                                        <div className={cx('proof-section')}>
                                            <span className={cx('small-title')}>Proof of Delivery</span>
                                            <SelectField
                                                clear={false}
                                                search={false}
                                                changeEvent={handleProofEvent}
                                                selected={proofValue}
                                                options={[
                                                    { value: '1', label: 'Signature' },
                                                    { value: '2', label: 'Photo' },
                                                    { value: '4', label: 'Payment' }
                                                ]}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <Field
                                name='notes'
                                type='text'
                                label='Note to Driver'
                                big
                                editable={true}
                                editMode={true}
                                component={LabeledItem}
                                className='mb-0 mt-20'
                            />
                        </div>
                    </form>
                </div>
            </div>
        )
    }
}