import * as React from 'react'

import Button from 'common/components/Button'

const cx = require('classnames/bind').bind(require('../styles/styles.scss'))

interface Props {

}

export default class TopSection extends React.Component<Props> {
    render() {
        return (
            <div>
                <div className={cx('top-section', 'flex align-items-center justify-content-between pl-15 pr-40 pt-30 pb-65')}>
                    <h3 className={cx('container-title')}>New Order</h3>
                    <div className={cx('buttons-holder', 'flex align-items-center')}>
                        <Button className={cx('save-order')}>Save</Button>
                        <Button className={cx('save-and-assign-order')}>Save & Assign to Driver</Button>
                        <Button red className={cx('cancel-order')}>Cancel</Button>
                    </div>
                </div>
                <div/>
            </div>
        )
    }
}