import * as React from 'react'
import {connect, DispatchProp} from 'react-redux'
import {InjectedFormProps, reduxForm} from 'redux-form'
import axios, {AxiosError, AxiosResponse} from 'axios'

import {history} from 'store'
import {State} from 'reducers'

import {
    hideSubmitLoader,
    setFormError,
    showSubmitLoader
} from '../actions'

import TopSection from '../components/TopSection'
import NewOrder from '../components/NewOrder'

interface FormProps {
    id: string,
    phone: string,
    first_name: string,
    last_name: string,
    email: string,
    payment_type: string,
    vehicle_type: string,
    amount: string,
    notes: string
}

interface Props {
    errorMessage: string,
    isShowSubmitLoader: boolean
}

interface DispatchProps {
    showSubmitLoader: () => void,
    hideSubmitLoader: () => void,
    setFormError: (error: any) => void
}

class NewOrderContainer extends React.Component<Props & DispatchProps & DispatchProp<{}> & InjectedFormProps<FormProps>> {
    state = {
        notificationValue: { value: '1', label: 'SMS' },
        proofValue: { value: '1', label: 'Signature' },
        tasksValue: undefined as any
    }

    componentWillMount() {
        const { initialize } = this.props

        initialize({
            payment_type: '1',
            vehicle_type: '1'
        })
    }

    render() {
        const { notificationValue, proofValue, tasksValue } = this.state
        return (
           <div>
               <TopSection/>
               <NewOrder
                    handleNotificationEvent={this.handleChangeNotification}
                    notificationValue={notificationValue}
                    handleProofEvent={this.handleChangeProof}
                    proofValue={proofValue}
                    handleTasksEvent={this.handleChangeTasks}
                    tasksValue={tasksValue}
               />
           </div>
        )
    }

    private handleChangeNotification = (selectedOption: any) => {
        this.setState({ notificationValue: selectedOption })
    }

    private handleChangeProof = (selectedOption: any) => {
        this.setState({ proofValue: selectedOption })
    }

    private handleChangeTasks = (selectedOption: any) => {
        this.setState({ tasksValue: selectedOption })
    }
}

const validate = (values: FormProps) => {
    const errors = {} as any
    const requiredMessage = 'This field is required.'

    console.log(values)

    if (!values.id) {
        errors.id = requiredMessage
    }

    if (!values.phone) {
        errors.phone = requiredMessage
    }

    if (!values.first_name) {
        errors.first_name = requiredMessage
    }

    return errors
}

const NewOrderReduxeForm = reduxForm({
    form: 'newOrderForm',
    validate
})(NewOrderContainer)

const mapStateToProps = (state: State) => {
    return {
        isShowSubmitLoader: state.newOrderForm.isShowSubmitLoader,
        errorMessage: state.newOrderForm.errorMessage
    }
}

export default connect(
    mapStateToProps,
    {
        setFormError,
        showSubmitLoader,
        hideSubmitLoader
    }
)(NewOrderReduxeForm as any)