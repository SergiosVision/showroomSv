export interface NewOrder {
    customer: {
        id: number,
        first_name: string,
        last_name: string,
        email: string,
        phone: string
    },
    customer_notification_type: number,
    destination: {
        area: string,
        block: number,
        street: string,
        jadda: number,
        building: string,
        floor: number,
        apartment: number,
        latitude: number,
        longitude: number
    },
    payment_type: number,
    proof_of_delivery: number,
    tasks: [number],
    amount: number,
    notes: string
    vehicle_type: number
}