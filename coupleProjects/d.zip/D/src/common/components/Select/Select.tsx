import * as React from 'react'
import Select from 'react-select'

const cx = require('classnames/bind').bind(require('./styles/Select.scss'))

interface Props {
    options: any,
    multi?: boolean,
    clear?: boolean
    search?: boolean,
    selected?: any,
    changeEvent: (selectedOption: any) => void,
    small?: boolean,
    big?: boolean
}

export default class SelectField extends React.Component<Props, {}> {
    state = {
        selectedOption: undefined as any
    }

    render() {
        const { options, clear, search, changeEvent, selected, small, big, multi } = this.props

        return(
            <div className={cx('select')}>
                <Select
                    value={selected}
                    onChange={changeEvent}
                    options={options}
                    isClearable={clear}
                    isSearchable={search}
                    isMulti={multi}
                    className={cx('react-select-container', {small, big})}
                    classNamePrefix='react-select'
                />
            </div>
        )
    }
}