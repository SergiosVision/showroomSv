module.exports = {
    path: 'https://api.dizli.net/v1',
    env: 'development',
    cacheBoosting: false
};
