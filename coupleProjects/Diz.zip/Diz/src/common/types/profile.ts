export interface ProfilePage {
    id: number,
    merchant_id: number,
    type: number,
    first_name: string,
    last_name: string
    email: string,
    phone: string
}