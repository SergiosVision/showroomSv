module.exports = {
    path: 'https://api.dizli.com',
    env: 'development',
    cacheBoosting: false
};
